import { useMutation, useQueryClient } from "@tanstack/react-query";
import { registrationsApi } from "../api/registrationsApi";
import { useToast } from "../../../hook/useToast";
import { QUERY_KEYS } from "../../../utils/constants";
import type { Event, AppApiError } from "../../../types";

export function useUnregister(eventId: number) {
  const queryClient = useQueryClient();
  const toast = useToast();
  const eventKey = [QUERY_KEYS.event, eventId];

  return useMutation({
    mutationFn: () => registrationsApi.cancel(eventId),

    onMutate: async () => {
      await queryClient.cancelQueries({ queryKey: eventKey });

      const previousEvent = queryClient.getQueryData<Event>(eventKey);

      if (previousEvent && previousEvent.registered_count > 0) {
        queryClient.setQueryData<Event>(eventKey, {
          ...previousEvent,
          registered_count: previousEvent.registered_count - 1,
        });
      }

      return { previousEvent };
    },

    onError: (error, _vars, context) => {
      if (context?.previousEvent) {
        queryClient.setQueryData(eventKey, context.previousEvent);
      }
      toast.error(error as unknown as AppApiError);
    },

    onSuccess: () => {
      toast.success("Registration cancelled");
      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.myRegistrations] });
    },

    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: eventKey });
    },
  });
}
