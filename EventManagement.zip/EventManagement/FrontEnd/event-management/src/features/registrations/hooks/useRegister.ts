import { useMutation, useQueryClient } from "@tanstack/react-query";
import { registrationsApi } from "../api/registrationsApi";
import { useToast } from "../../../hook/useToast";
import { QUERY_KEYS } from "../../../utils/constants";
import type { Event, AppApiError } from "../../../types";

/**
 * Registers the current user for an event.
 *
 * Optimistic flow:
 * 1. Immediately increment registered_count in the cached Event (assume 'confirmed').
 * 2. On success, reconcile with the server's actual registration status
 *    (could be 'confirmed' OR 'waitlisted' if capacity filled between
 *    the optimistic update and the server's transaction).
 * 3. On error (esp. 409 Conflict — race lost to another user), roll back
 *    the cache to its pre-mutation snapshot and show a clear message.
 */
export function useRegister(eventId: number) {
  const queryClient = useQueryClient();
  const toast = useToast();
  const eventKey = [QUERY_KEYS.event, eventId];

  return useMutation({
    mutationFn: () => registrationsApi.register(eventId),

    onMutate: async () => {
      await queryClient.cancelQueries({ queryKey: eventKey });

      const previousEvent = queryClient.getQueryData<Event>(eventKey);

      if (previousEvent) {
        queryClient.setQueryData<Event>(eventKey, {
          ...previousEvent,
          registered_count: previousEvent.registered_count + 1,
        });
      }

      // Snapshot for rollback
      return { previousEvent };
    },

    onError: (error, _vars, context) => {
      // Roll back to the pre-mutation snapshot
      if (context?.previousEvent) {
        queryClient.setQueryData(eventKey, context.previousEvent);
      }

      const apiError = error as unknown as AppApiError;
      if (apiError.statusCode === 409) {
        toast.error({
          ...apiError,
          message:
            apiError.message ||
            "This event just filled up — please refresh and try again.",
        } as AppApiError);
        // Force a refetch so the user sees the true, current capacity
        queryClient.invalidateQueries({ queryKey: eventKey });
      } else {
        toast.error(apiError);
      }
    },

    onSuccess: (registration) => {
      if (registration.status === "waitlisted") {
        toast.info(
          "You've been added to the waitlist — we'll notify you if a spot opens up.",
        );
      } else {
        toast.success("You're registered! See you there.");
      }

      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.myRegistrations] });
    },

    onSettled: () => {
      // Always reconcile with server truth, whether success or failure
      queryClient.invalidateQueries({ queryKey: eventKey });
    },
  });
}
