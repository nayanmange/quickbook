import { useQuery, keepPreviousData } from "@tanstack/react-query";
import { registrationsApi } from "../api/registrationsApi";
import { QUERY_KEYS } from "../../../utils/constants";
import type { RegistrationStatus } from "../../../types";

export function useMyRegistrations(
  page: number,
  limit: number,
  status?: RegistrationStatus,
) {
  return useQuery({
    queryKey: [QUERY_KEYS.myRegistrations, { page, limit, status }],
    queryFn: () => registrationsApi.listMine({ page, limit, status }),
    placeholderData: keepPreviousData,
  });
}
