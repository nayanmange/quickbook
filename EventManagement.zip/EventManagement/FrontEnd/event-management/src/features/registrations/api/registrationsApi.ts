import { api } from "../../../lib/axios";
import type {
  ApiSuccessResponse,
  Registration,
  RegistrationWithEvent,
  AttendeeRegistration,
  PaginatedResult,
  RegistrationStatus,
} from "../../../types";

interface ListParams {
  page?: number;
  limit?: number;
  status?: RegistrationStatus;
}

export const registrationsApi = {
  register: async (eventId: number): Promise<Registration> => {
    const { data } = await api.post<ApiSuccessResponse<Registration>>(
      `/registrations/events/${eventId}`,
    );
    return data.data;
  },

  cancel: async (eventId: number): Promise<void> => {
    await api.delete(`/registrations/events/${eventId}`);
  },

  listMine: async (
    params: ListParams,
  ): Promise<PaginatedResult<RegistrationWithEvent>> => {
    const { data } = await api.get<
      ApiSuccessResponse<PaginatedResult<RegistrationWithEvent>>
    >("/registrations/my", {
      params: {
        page: params.page ?? 1,
        limit: params.limit ?? 10,
        status: params.status,
      },
    });
    return data.data;
  },

  listForEvent: async (
    eventId: number,
    params: ListParams,
  ): Promise<PaginatedResult<AttendeeRegistration>> => {
    const { data } = await api.get<
      ApiSuccessResponse<PaginatedResult<AttendeeRegistration>>
    >(`/registrations/events/${eventId}`, {
      params: {
        page: params.page ?? 1,
        limit: params.limit ?? 10,
        status: params.status,
      },
    });
    return data.data;
  },
};
