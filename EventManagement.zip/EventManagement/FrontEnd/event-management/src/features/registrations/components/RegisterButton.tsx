import { useMemo } from "react";
import { Button } from "../../../components/ui/Button";
import { useAuth } from "../../auth/hooks/useAuth";
import { useRegister } from "../hooks/useRegister";
import { useUnregister } from "../hooks/useUnregister";
import { useMyRegistrations } from "../hooks/useMyRegistrations";
import {
  getEventAvailability,
  isEventInPast,
} from "../../events/utils/eventAvailability";
import { useNavigate } from "react-router-dom";
import { ROUTES } from "../../../utils/constants";
import type { Event, RegistrationState } from "../../../types";

interface RegisterButtonProps {
  event: Event;
}

/**
 * Derives the participant's RegistrationState for this event from the
 * "my registrations" cache, then renders the appropriate action.
 *
 * NOTE: this performs a client-side scan over the user's registrations.
 * For very large registration histories, exposing a dedicated
 * GET /registrations/my?event_id= endpoint would be preferable —
 * documented here as a known trade-off for this assignment's scope.
 */
export function RegisterButton({ event }: RegisterButtonProps) {
  const { isAuthenticated, user } = useAuth();
  const navigate = useNavigate();

  // Fetch a reasonably-sized page of the user's registrations to check status.
  // Only runs for authenticated participants.
  const { data: myRegistrations } = useMyRegistrations(1, 100);

  const registerMutation = useRegister(event.id);
  const unregisterMutation = useUnregister(event.id);

  const registrationState: RegistrationState = useMemo(() => {
    if (!isAuthenticated || !myRegistrations)
      return { status: "not_registered" };

    const match = myRegistrations.data.find((r) => r.event_id === event.id);
    if (!match) return { status: "not_registered" };

    if (match.status === "confirmed")
      return { status: "confirmed", registrationId: match.id };
    if (match.status === "waitlisted")
      return { status: "waitlisted", registrationId: match.id };
    return { status: "not_registered" };
  }, [isAuthenticated, myRegistrations, event.id]);

  const availability = getEventAvailability(event);
  const eventEnded = isEventInPast(event);

  // --- Not logged in ---
  if (!isAuthenticated) {
    return (
      <Button
        onClick={() => navigate(ROUTES.LOGIN, { state: { from: location } })}
      >
        Sign in to register
      </Button>
    );
  }

  // --- Organizers/admins don't register for events ---
  if (user?.role === "organizer" || user?.role === "admin") {
    return null;
  }

  // --- Event has already ended ---
  if (eventEnded) {
    return (
      <Button disabled variant="secondary">
        Event has ended
      </Button>
    );
  }

  // --- Already registered (confirmed) ---
  if (registrationState.status === "confirmed") {
    return (
      <Button
        variant="danger"
        isLoading={unregisterMutation.isPending}
        onClick={() => unregisterMutation.mutate()}
      >
        {unregisterMutation.isPending ? "Cancelling…" : "Unregister"}
      </Button>
    );
  }

  // --- Already waitlisted ---
  if (registrationState.status === "waitlisted") {
    return (
      <div className="flex items-center gap-3">
        <Button disabled variant="secondary">
          You're on the waitlist
        </Button>
        <Button
          variant="ghost"
          size="sm"
          isLoading={unregisterMutation.isPending}
          onClick={() => unregisterMutation.mutate()}
        >
          Leave waitlist
        </Button>
      </div>
    );
  }

  // --- Event isn't published yet ---
  if (event.status !== "published") {
    return (
      <Button disabled variant="secondary">
        Registration not yet open
      </Button>
    );
  }

  // --- Not registered: available, waitlist, or sold out ---
  if (availability.kind === "sold_out") {
    return (
      <Button disabled variant="secondary">
        Sold out
      </Button>
    );
  }

  const isWaitlist = availability.kind === "waitlist_open";

  return (
    <Button
      variant={isWaitlist ? "secondary" : "primary"}
      isLoading={registerMutation.isPending}
      onClick={() => registerMutation.mutate()}
    >
      {registerMutation.isPending
        ? "Registering…"
        : isWaitlist
          ? "Join Waitlist"
          : "Register"}
    </Button>
  );
}
