import { Link } from "react-router-dom";
import { Calendar, ExternalLink } from "lucide-react";
import { Card, CardBody } from "../../../components/ui/Card";
import { Badge } from "../../../components/ui/Badge";
import { Button } from "../../../components/ui/Button";
import { formatDateTime } from "../../../utils/formatDate";
import { useUnregister } from "../hooks/useUnregister";
import { ROUTES } from "../../../utils/constants";
import type { RegistrationWithEvent } from "../../../types";

const STATUS_VARIANT = {
  confirmed: "success",
  waitlisted: "warning",
  cancelled: "default",
} as const;

export function TicketCard({
  registration,
}: {
  registration: RegistrationWithEvent;
}) {
  const unregisterMutation = useUnregister(registration.event_id);
  const isCancelled = registration.status === "cancelled";

  return (
    <Card>
      <CardBody className="flex flex-col gap-3">
        <div className="flex items-start justify-between gap-2">
          <Badge variant={STATUS_VARIANT[registration.status]}>
            {registration.status.charAt(0).toUpperCase() +
              registration.status.slice(1)}
          </Badge>
          <Badge variant="default">{registration.event_status}</Badge>
        </div>

        <h3 className="text-base font-semibold text-slate-900">
          {registration.event_title}
        </h3>

        <div className="flex items-center gap-2 text-sm text-slate-500">
          <Calendar className="h-4 w-4" />
          <span>{formatDateTime(registration.event_start_time)}</span>
        </div>

        <div className="mt-2 flex gap-2">
          <Link to={ROUTES.EVENT_DETAILS(registration.event_id)}>
            <Button variant="secondary" size="sm">
              <ExternalLink className="h-4 w-4" />
              View event
            </Button>
          </Link>

          {!isCancelled && (
            <Button
              variant="danger"
              size="sm"
              isLoading={unregisterMutation.isPending}
              onClick={() => unregisterMutation.mutate()}
            >
              Cancel
            </Button>
          )}
        </div>
      </CardBody>
    </Card>
  );
}
