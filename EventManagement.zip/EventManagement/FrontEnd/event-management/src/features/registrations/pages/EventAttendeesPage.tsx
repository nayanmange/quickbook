import { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { Users, ArrowLeft } from "lucide-react";
import { ErrorBoundary } from "react-error-boundary";
import { Card, CardBody } from "../../../components/ui/Card";
import { Badge } from "../../../components/ui/Badge";
import { EmptyState } from "../../../components/ui/EmptyState";
import { Pagination } from "../../../components/ui/Pagination";
import { Skeleton } from "../../../components/ui/Skeleton";
import { QueryErrorFallback } from "../../../components/QueryErrorFallback";
import { useEventAttendees } from "../hooks/useEventAttendees";
import { useEvent } from "../../events/hooks/useEvent";
import { formatDateTime } from "../../../utils/formatDate";
import { DEFAULT_PAGE_SIZE, ROUTES } from "../../../utils/constants";

const STATUS_VARIANT = {
  confirmed: "success",
  waitlisted: "warning",
  cancelled: "default",
} as const;

export default function EventAttendeesPage() {
  const { id } = useParams<{ id: string }>();
  const eventId = Number(id);
  const [page, setPage] = useState(1);

  const { data: event } = useEvent(eventId, { poll: false });

  return (
    <div className="flex flex-col gap-6">
      <div>
        <Link
          to={ROUTES.ORGANIZER_EVENTS}
          className="mb-2 inline-flex items-center gap-1 text-sm text-slate-500 hover:text-slate-700"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to my events
        </Link>
        <h1 className="text-2xl font-bold text-slate-900">
          Attendees{event ? ` — ${event.title}` : ""}
        </h1>
        {event && (
          <p className="mt-1 text-sm text-slate-500">
            {event.registered_count} / {event.capacity} registered
          </p>
        )}
      </div>

      <ErrorBoundary FallbackComponent={QueryErrorFallback}>
        <AttendeesList eventId={eventId} page={page} onPageChange={setPage} />
      </ErrorBoundary>
    </div>
  );
}

function AttendeesList({
  eventId,
  page,
  onPageChange,
}: {
  eventId: number;
  page: number;
  onPageChange: (p: number) => void;
}) {
  const { data, isLoading, isError, error } = useEventAttendees(
    eventId,
    page,
    DEFAULT_PAGE_SIZE,
  );

  if (isLoading) {
    return (
      <div className="flex flex-col gap-2">
        {Array.from({ length: 5 }).map((_, i) => (
          <Skeleton key={i} className="h-14 rounded-lg" />
        ))}
      </div>
    );
  }

  if (isError) throw error;

  if (!data || data.data.length === 0) {
    return (
      <EmptyState
        icon={<Users className="h-12 w-12" />}
        title="No registrations yet"
        description="Once participants register, they'll show up here."
      />
    );
  }

  return (
    <Card>
      <CardBody className="flex flex-col gap-2 p-0">
        <div className="hidden grid-cols-[2fr_2fr_1fr_1fr] gap-4 border-b border-slate-100 px-4 py-2 text-xs font-medium uppercase text-slate-400 sm:grid">
          <span>Name</span>
          <span>Email</span>
          <span>Status</span>
          <span>Registered</span>
        </div>
        {data.data.map((attendee) => (
          <div
            key={attendee.id}
            className="grid grid-cols-1 gap-1 border-b border-slate-50 px-4 py-3 last:border-0 sm:grid-cols-[2fr_2fr_1fr_1fr] sm:items-center sm:gap-4"
          >
            <span className="font-medium text-slate-900">
              {attendee.user_name}
            </span>
            <span className="text-sm text-slate-500">
              {attendee.user_email}
            </span>
            <span>
              <Badge variant={STATUS_VARIANT[attendee.status]}>
                {attendee.status.charAt(0).toUpperCase() +
                  attendee.status.slice(1)}
              </Badge>
            </span>
            <span className="text-sm text-slate-500">
              {formatDateTime(attendee.registered_at)}
            </span>
          </div>
        ))}
        <div className="px-4 py-3">
          <Pagination
            pagination={data.pagination}
            onPageChange={onPageChange}
          />
        </div>
      </CardBody>
    </Card>
  );
}
