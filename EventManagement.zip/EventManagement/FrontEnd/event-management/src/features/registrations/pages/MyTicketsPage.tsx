import { useState } from "react";
import { Ticket } from "lucide-react";
import { Link } from "react-router-dom";
import { ErrorBoundary } from "react-error-boundary";
import { TicketCard } from "../components/TicketCard";
import { EmptyState } from "../../../components/ui/EmptyState";
import { Button } from "../../../components/ui/Button";
import { Pagination } from "../../../components/ui/Pagination";
import { Skeleton } from "../../../components/ui/Skeleton";
import { QueryErrorFallback } from "../../../components/QueryErrorFallback";
import { useMyRegistrations } from "../hooks/useMyRegistrations";
import { DEFAULT_PAGE_SIZE, ROUTES } from "../../../utils/constants";

export default function MyTicketsPage() {
  const [page, setPage] = useState(1);

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">My Tickets</h1>
        <p className="mt-1 text-sm text-slate-500">
          Events you've registered for or are waitlisted on.
        </p>
      </div>

      <ErrorBoundary FallbackComponent={QueryErrorFallback}>
        <TicketsList page={page} onPageChange={setPage} />
      </ErrorBoundary>
    </div>
  );
}

function TicketsList({
  page,
  onPageChange,
}: {
  page: number;
  onPageChange: (p: number) => void;
}) {
  const { data, isLoading, isError, error } = useMyRegistrations(
    page,
    DEFAULT_PAGE_SIZE,
  );

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {Array.from({ length: 3 }).map((_, i) => (
          <Skeleton key={i} className="h-40 rounded-xl" />
        ))}
      </div>
    );
  }

  if (isError) throw error;

  if (!data || data.data.length === 0) {
    return (
      <EmptyState
        icon={<Ticket className="h-12 w-12" />}
        title="No tickets yet"
        description="You haven't registered for any events. Discover something interesting to attend!"
        action={
          <Link to={ROUTES.DISCOVER}>
            <Button>Browse events</Button>
          </Link>
        }
      />
    );
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {data.data.map((reg) => (
          <TicketCard key={reg.id} registration={reg} />
        ))}
      </div>
      <Pagination pagination={data.pagination} onPageChange={onPageChange} />
    </div>
  );
}
