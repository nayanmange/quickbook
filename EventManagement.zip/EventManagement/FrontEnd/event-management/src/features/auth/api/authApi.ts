import { api } from "../../../lib/axios";
import type { ApiSuccessResponse, User } from "../../../types";
import type {
  LoginFormValues,
  RegisterFormValues,
} from "../schemas/authSchema";

interface AuthResponseData {
  user: User;
  accessToken: string;
}

export const authApi = {
  login: async (payload: LoginFormValues): Promise<AuthResponseData> => {
    const { data } = await api.post<ApiSuccessResponse<AuthResponseData>>(
      "/auth/login",
      payload,
    );
    return data.data;
  },

  register: async (
    payload: Omit<RegisterFormValues, "confirmPassword">,
  ): Promise<AuthResponseData> => {
    const { data } = await api.post<ApiSuccessResponse<AuthResponseData>>(
      "/auth/register",
      payload,
    );
    return data.data;
  },

  logout: async (): Promise<void> => {
    await api.post("/auth/logout");
  },
};
