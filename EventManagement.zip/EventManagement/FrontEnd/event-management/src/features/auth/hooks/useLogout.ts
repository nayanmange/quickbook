import { useMutation } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { authApi } from "../api/authApi";
import { useAuthStore } from "../store/authStore";
import { queryClient } from "../../../lib/queryClient";
import { ROUTES } from "../../../utils/constants";

export function useLogout() {
  const logout = useAuthStore((s) => s.logout);
  const navigate = useNavigate();

  return useMutation({
    mutationFn: authApi.logout,
    onSettled: () => {
      // Clear regardless of API success — user intent is to log out
      logout();
      queryClient.clear();
      navigate(ROUTES.LOGIN, { replace: true });
    },
  });
}
