import { useMutation } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { authApi } from "../api/authApi";
import { useAuthStore } from "../store/authStore";
import { useToast } from "../../../hook/useToast";
import { ROUTES } from "../../../utils/constants";
import type { RegisterFormValues } from "../schemas/authSchema";

export function useRegister() {
  const setAuth = useAuthStore((s) => s.setAuth);
  const navigate = useNavigate();
  const toast = useToast();

  return useMutation({
    mutationFn: (payload: RegisterFormValues) => {
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      const { confirmPassword, ...rest } = payload;
      return authApi.register(rest);
    },
    onSuccess: ({ user, accessToken }) => {
      setAuth(user, accessToken);
      toast.success(`Welcome, ${user.name}!`);

      const home =
        user.role === "organizer"
          ? ROUTES.ORGANIZER_DASHBOARD
          : ROUTES.DISCOVER;
      navigate(home, { replace: true });
    },
    onError: (error) => toast.error(error),
  });
}
