// ============================================
// src/features/auth/hooks/useAuth.ts
// ============================================

import { useEffect } from "react";
import { useAuthStore } from "../store/authStore";
import { api } from "../../../lib/axios";
import type { ApiSuccessResponse, User } from "../../../types";

interface RefreshResponseData {
  user: User;
  accessToken: string;
}

/**
 * On initial app load, attempts a silent refresh using the HttpOnly cookie.
 * If it succeeds, the user session is restored without requiring re-login.
 * If it fails (no cookie / expired), the user remains logged out.
 */
export function useAuthBootstrap(): void {
  const setAuth = useAuthStore((state) => state.setAuth);
  const setHydrated = useAuthStore((state) => state.setHydrated);
  const hasHydrated = useAuthStore((state) => state.hasHydrated);

  useEffect(() => {
    if (hasHydrated) return;

    let cancelled = false;

    (async () => {
      try {
        const { data } =
          await api.post<ApiSuccessResponse<RefreshResponseData>>(
            "/auth/refresh",
          );
        if (!cancelled) {
          setAuth(data.data.user, data.data.accessToken);
        }
      } catch {
        if (!cancelled) setHydrated(true);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [hasHydrated, setAuth, setHydrated]);
}

export function useAuth() {
  const user = useAuthStore((state) => state.user);
  const accessToken = useAuthStore((state) => state.accessToken);
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);
  const hasHydrated = useAuthStore((state) => state.hasHydrated);

  return { user, accessToken, isAuthenticated, hasHydrated };
}
