import { useMutation } from "@tanstack/react-query";
import { useNavigate, useLocation } from "react-router-dom";
import { authApi } from "../api/authApi";
import { useAuthStore } from "../store/authStore";
import { useToast } from "../../../hook/useToast";
import { ROUTES } from "../../../utils/constants";
import type { LoginFormValues } from "../schemas/authSchema";

export function useLogin() {
  const setAuth = useAuthStore((s) => s.setAuth);
  const navigate = useNavigate();
  const location = useLocation();
  const toast = useToast();

  return useMutation({
    mutationFn: (payload: LoginFormValues) => authApi.login(payload),
    onSuccess: ({ user, accessToken }) => {
      setAuth(user, accessToken);
      toast.success(`Welcome back, ${user.name}!`);

      // Respect the page the user was trying to access before being redirected to /login
      const from = (location.state as { from?: Location })?.from?.pathname;
      const fallback =
        user.role === "organizer"
          ? ROUTES.ORGANIZER_DASHBOARD
          : ROUTES.DISCOVER;
      navigate(from || fallback, { replace: true });
    },
    onError: (error) => toast.error(error),
  });
}
