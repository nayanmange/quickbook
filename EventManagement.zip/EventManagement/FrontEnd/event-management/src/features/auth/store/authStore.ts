// ============================================
// src/features/auth/store/authStore.ts
// ============================================

import { create } from "zustand";
import type { User } from "../../../types";

interface AuthStore {
  user: User | null;
  accessToken: string | null;
  isAuthenticated: boolean;
  hasHydrated: boolean; // true once the initial /auth/refresh check resolves
  setAuth: (user: User, accessToken: string) => void;
  setAccessToken: (accessToken: string) => void;
  setHydrated: (value: boolean) => void;
  logout: () => void;
}

/**
 * Auth state is kept in memory only (no localStorage), since the refresh
 * token lives in an HttpOnly cookie. On app load, an /auth/refresh call
 * (see useAuth hook) silently restores the session.
 *
 * NOTE: The explicit `<AuthStore>` type argument on `create` is required —
 * without it, `create()(...)` infers the store type from the returned
 * object and the `set`/selector parameters fall back to `any`, which
 * triggers "Parameter 's' implicitly has an 'any' type" wherever
 * `useAuthStore((s) => s.someField)` is called.
 */
export const useAuthStore = create<AuthStore>((set) => ({
  user: null,
  accessToken: null,
  isAuthenticated: false,
  hasHydrated: false,

  setAuth: (user, accessToken) =>
    set({ user, accessToken, isAuthenticated: true, hasHydrated: true }),

  setAccessToken: (accessToken) => set({ accessToken }),

  setHydrated: (value) => set({ hasHydrated: value }),

  logout: () =>
    set({
      user: null,
      accessToken: null,
      isAuthenticated: false,
      hasHydrated: true,
    }),
}));
