import { RegisterForm } from "../components/RegisterForm";
import { Card, CardBody } from "../../../components/ui/Card";

export default function RegisterPage() {
  return (
    <div className="flex min-h-[80vh] items-center justify-center">
      <div className="w-full max-w-sm">
        <div className="mb-6 text-center">
          <h1 className="text-2xl font-bold text-slate-900">
            Create your account
          </h1>
          <p className="mt-1 text-sm text-slate-500">
            Join as an organizer or participant
          </p>
        </div>
        <Card>
          <CardBody>
            <RegisterForm />
          </CardBody>
        </Card>
      </div>
    </div>
  );
}
