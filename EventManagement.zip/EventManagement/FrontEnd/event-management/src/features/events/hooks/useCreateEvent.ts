import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { eventsApi } from "../api/eventsApi";
import { useToast } from "../../../hook/useToast";
import { QUERY_KEYS, ROUTES } from "../../../utils/constants";
import type { CreateEventPayload } from "../../../types";

export function useCreateEvent() {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const toast = useToast();

  return useMutation({
    mutationFn: (payload: CreateEventPayload) => eventsApi.create(payload),
    onSuccess: (event) => {
      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.myEvents] });
      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.events] });
      toast.success("Event created successfully");
      navigate(ROUTES.EVENT_DETAILS(event.id));
    },
    onError: (error) => toast.error(error),
  });
}
