import { useQuery, keepPreviousData } from "@tanstack/react-query";
import { eventsApi } from "../api/eventsApi";
import { QUERY_KEYS } from "../../../utils/constants";
import type { EventFilters } from "../../../types";

/** Organizer's own events — used by Dashboard + Event Management list */
export function useMyEvents(filters: EventFilters) {
  return useQuery({
    queryKey: [QUERY_KEYS.myEvents, filters],
    queryFn: () => eventsApi.listMine(filters),
    placeholderData: keepPreviousData,
  });
}
