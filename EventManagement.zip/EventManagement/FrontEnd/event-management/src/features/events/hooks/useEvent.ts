import { useQuery } from "@tanstack/react-query";
import { eventsApi } from "../api/eventsApi";
import { QUERY_KEYS } from "../../../utils/constants";

const THIRTY_SECONDS = 30_000;

/**
 * Single event details. Polls every 30s so capacity/availability
 * stays live for users sitting on the details page — refetches
 * even while the tab is in the background is avoided via
 * refetchIntervalInBackground: false (default).
 */
export function useEvent(id: number, options?: { poll?: boolean }) {
  const poll = options?.poll ?? true;

  return useQuery({
    queryKey: [QUERY_KEYS.event, id],
    queryFn: () => eventsApi.getById(id),
    enabled: Number.isFinite(id) && id > 0,
    refetchInterval: poll ? THIRTY_SECONDS : false,
  });
}
