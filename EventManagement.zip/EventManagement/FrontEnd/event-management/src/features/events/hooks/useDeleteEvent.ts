import { useMutation, useQueryClient } from "@tanstack/react-query";
import { eventsApi } from "../api/eventsApi";
import { useToast } from "../../../hook/useToast";
import { QUERY_KEYS } from "../../../utils/constants";

export function useDeleteEvent() {
  const queryClient = useQueryClient();
  const toast = useToast();

  return useMutation({
    mutationFn: (id: number) => eventsApi.remove(id),
    onSuccess: (_data, id) => {
      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.myEvents] });
      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.events] });
      queryClient.removeQueries({ queryKey: [QUERY_KEYS.event, id] });
      toast.success("Event deleted");
    },
    onError: (error) => toast.error(error),
  });
}
