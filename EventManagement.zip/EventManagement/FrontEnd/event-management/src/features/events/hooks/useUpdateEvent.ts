import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { eventsApi } from "../api/eventsApi";
import { useToast } from "../../../hook/useToast";
import { QUERY_KEYS, ROUTES } from "../../../utils/constants";
import type { UpdateEventPayload } from "../../../types";

export function useUpdateEvent(id: number) {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const toast = useToast();

  return useMutation({
    mutationFn: (payload: UpdateEventPayload) => eventsApi.update(id, payload),
    onSuccess: (event) => {
      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.myEvents] });
      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.events] });
      queryClient.setQueryData([QUERY_KEYS.event, id], event);
      toast.success("Event updated successfully");
      navigate(ROUTES.EVENT_DETAILS(event.id));
    },
    onError: (error) => toast.error(error),
  });
}
