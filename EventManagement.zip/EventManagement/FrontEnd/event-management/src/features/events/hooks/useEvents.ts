import { useQuery, keepPreviousData } from "@tanstack/react-query";
import { eventsApi } from "../api/eventsApi";
import { QUERY_KEYS } from "../../../utils/constants";
import type { EventFilters } from "../../../types";

/**
 * Event Discovery list. Uses keepPreviousData so pagination/filter
 * changes don't flash an empty/skeleton state — old data stays
 * visible (dimmed) while the new page loads.
 */
export function useEvents(filters: EventFilters) {
  return useQuery({
    queryKey: [QUERY_KEYS.events, filters],
    queryFn: () => eventsApi.list(filters),
    placeholderData: keepPreviousData,
  });
}
