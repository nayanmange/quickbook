import { api } from "../../../lib/axios";
import type {
  ApiSuccessResponse,
  Event,
  EventFilters,
  PaginatedResult,
  CreateEventPayload,
  UpdateEventPayload,
} from "../../../types";

function buildEventQueryParams(
  filters: EventFilters,
): Record<string, string | number> {
  const params: Record<string, string | number> = {
    page: filters.page ?? 1,
    limit: filters.limit ?? 10,
  };

  if (filters.type) params.type = filters.type;
  if (filters.status) params.status = filters.status;
  if (filters.from) params.from = filters.from;
  if (filters.to) params.to = filters.to;
  if (filters.search) params.search = filters.search;

  return params;
}

export const eventsApi = {
  list: async (filters: EventFilters): Promise<PaginatedResult<Event>> => {
    const { data } = await api.get<ApiSuccessResponse<PaginatedResult<Event>>>(
      "/events",
      {
        params: buildEventQueryParams(filters),
      },
    );
    return data.data;
  },

  getById: async (id: number): Promise<Event> => {
    const { data } = await api.get<ApiSuccessResponse<Event>>(`/events/${id}`);
    return data.data;
  },

  listMine: async (filters: EventFilters): Promise<PaginatedResult<Event>> => {
    const { data } = await api.get<ApiSuccessResponse<PaginatedResult<Event>>>(
      "/events/my",
      {
        params: buildEventQueryParams(filters),
      },
    );
    return data.data;
  },

  create: async (payload: CreateEventPayload): Promise<Event> => {
    const { data } = await api.post<ApiSuccessResponse<Event>>(
      "/events",
      payload,
    );
    return data.data;
  },

  update: async (id: number, payload: UpdateEventPayload): Promise<Event> => {
    const { data } = await api.put<ApiSuccessResponse<Event>>(
      `/events/${id}`,
      payload,
    );
    return data.data;
  },

  remove: async (id: number): Promise<void> => {
    await api.delete(`/events/${id}`);
  },
};
