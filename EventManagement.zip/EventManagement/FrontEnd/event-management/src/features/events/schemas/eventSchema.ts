import { z } from "zod";
import { EVENT_TYPES, EVENT_STATUSES } from "../../../utils/constants";

const eventTypeValues = EVENT_TYPES.map((t) => t.value) as [
  string,
  ...string[],
];
const eventStatusValues = EVENT_STATUSES.map((s) => s.value) as [
  string,
  ...string[],
];

/**
 * Form-level schema operates on <input type="datetime-local"> strings
 * (format: "YYYY-MM-DDTHH:mm", NO timezone info, NO seconds).
 *
 * IMPORTANT: We do NOT use z.string().datetime() here. Zod's .datetime()
 * requires a full ISO-8601 string WITH timezone info (e.g. trailing "Z"),
 * which <input type="datetime-local"> never produces. Using .datetime()
 * on this field causes EVERY submission to fail validation silently
 * (react-hook-form's handleSubmit simply never calls onSubmit, and the
 * error often isn't rendered prominently), which looks exactly like
 * "the Save button does nothing."
 *
 * Instead we validate it's a non-empty string that `new Date(...)` can
 * parse - the actual ISO/UTC conversion happens later via
 * localDateTimeToUtcIso() in the submit handler.
 */
const localDateTimeString = z
  .string()
  .min(1, "This field is required")
  .refine((val) => !Number.isNaN(new Date(val).getTime()), {
    message: "Enter a valid date and time",
  });

export const eventFormSchema = z
  .object({
    title: z.string().min(3, "Title must be at least 3 characters").max(200),
    description: z.string().max(5000).optional().or(z.literal("")),
    type: z.enum(eventTypeValues as [string, ...string[]], {
      errorMap: () => ({ message: "Please select an event type" }),
    }),
    is_online: z.boolean(),
    location: z.string().max(255).optional().or(z.literal("")),
    capacity: z
      .number({ invalid_type_error: "Capacity is required" })
      .int("Capacity must be a whole number")
      .positive("Capacity must be a positive integer"),
    start_time: localDateTimeString,
    end_time: localDateTimeString,
    status: z.enum(eventStatusValues as [string, ...string[]]).optional(),
  })
  .superRefine((data, ctx) => {
    // --- End must be after start ---
    if (data.start_time && data.end_time) {
      const start = new Date(data.start_time);
      const end = new Date(data.end_time);
      if (end <= start) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "End date & time must be after start date & time",
          path: ["end_time"],
        });
      }
    }

    // --- Location rules depend on is_online ---
    if (data.is_online) {
      if (!data.location || data.location.trim() === "") {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "A meeting URL is required for virtual events",
          path: ["location"],
        });
      } else {
        try {
          const url = new URL(data.location);
          if (!["http:", "https:"].includes(url.protocol)) throw new Error();
        } catch {
          ctx.addIssue({
            code: z.ZodIssueCode.custom,
            message: "Enter a valid URL (e.g. https://zoom.us/j/...)",
            path: ["location"],
          });
        }
      }
    } else {
      if (!data.location || data.location.trim() === "") {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "A physical location is required for in-person events",
          path: ["location"],
        });
      }
    }
  });

export type EventFormValues = z.infer<typeof eventFormSchema>;
