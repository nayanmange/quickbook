import { Skeleton } from "../../../components/ui/Skeleton";
import { Card, CardBody } from "../../../components/ui/Card";

export function EventDetailsSkeleton() {
  return (
    <div className="mx-auto max-w-3xl">
      <Skeleton className="mb-4 h-6 w-24 rounded-full" />
      <Skeleton className="mb-2 h-9 w-3/4" />
      <Skeleton className="mb-6 h-4 w-1/2" />
      <Card>
        <CardBody className="flex flex-col gap-4">
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-2/3" />
          <Skeleton className="h-10 w-40" />
        </CardBody>
      </Card>
    </div>
  );
}
