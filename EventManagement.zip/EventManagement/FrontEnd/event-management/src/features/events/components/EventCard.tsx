import { Link } from "react-router-dom";
import { Calendar, MapPin, Users, Video } from "lucide-react";
import { Card, CardBody } from "../../../components/ui/Card";
import { Badge } from "../../../components/ui/Badge";
import { formatDateTime } from "../../../utils/formatDate";
import { getEventAvailability } from "../utils/eventAvailability";
import { EVENT_TYPES, ROUTES } from "../../../utils/constants";
import type { Event } from "../../../types";

interface EventCardProps {
  event: Event;
}

const TYPE_LABELS = Object.fromEntries(
  EVENT_TYPES.map((t) => [t.value, t.label]),
);

export function EventCard({ event }: EventCardProps) {
  const availability = getEventAvailability(event);

  return (
    <Link to={ROUTES.EVENT_DETAILS(event.id)}>
      <Card className="h-full transition-shadow hover:shadow-md">
        <CardBody className="flex h-full flex-col gap-3">
          <div className="flex items-start justify-between gap-2">
            <Badge variant="info">
              {TYPE_LABELS[event.type] ?? event.type}
            </Badge>
            <CapacityBadge availability={availability} />
          </div>

          <h3 className="line-clamp-2 text-base font-semibold text-slate-900">
            {event.title}
          </h3>

          {event.description && (
            <p className="line-clamp-2 text-sm text-slate-500">
              {event.description}
            </p>
          )}

          <div className="mt-auto flex flex-col gap-1.5 text-sm text-slate-500">
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4 shrink-0" />
              <span>{formatDateTime(event.start_time)}</span>
            </div>
            <div className="flex items-center gap-2">
              {event.is_online ? (
                <Video className="h-4 w-4 shrink-0" />
              ) : (
                <MapPin className="h-4 w-4 shrink-0" />
              )}
              <span className="truncate">
                {event.is_online ? "Online event" : event.location}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Users className="h-4 w-4 shrink-0" />
              <span>
                {event.registered_count} / {event.capacity} registered
              </span>
            </div>
          </div>
        </CardBody>
      </Card>
    </Link>
  );
}

function CapacityBadge({
  availability,
}: {
  availability: ReturnType<typeof getEventAvailability>;
}) {
  switch (availability.kind) {
    case "available":
      return (
        <Badge variant="success">
          {availability.seatsRemaining} seats left
        </Badge>
      );
    case "waitlist_open":
      return <Badge variant="warning">Join waitlist</Badge>;
    case "sold_out":
      return <Badge variant="danger">Sold out</Badge>;
  }
}
