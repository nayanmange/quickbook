import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Input } from "../../../components/ui/Input";
import { Textarea } from "../../../components/ui/Textarea";
import { Select } from "../../../components/ui/Select";
import { Button } from "../../../components/ui/Button";
import { eventFormSchema, type EventFormValues } from "../schemas/eventSchema";
import { EVENT_TYPES, EVENT_STATUSES } from "../../../utils/constants";
import {
  localDateTimeToUtcIso,
  utcIsoToLocalDateTimeInput,
} from "../../../utils/formatDate";
import type { Event, CreateEventPayload } from "../../../types";

interface EventFormProps {
  defaultValues?: Event;
  onSubmit: (payload: CreateEventPayload) => void;
  isSubmitting: boolean;
  submitLabel: string;
}

export function EventForm({
  defaultValues,
  onSubmit,
  isSubmitting,
  submitLabel,
}: EventFormProps) {
  const {
    register,
    handleSubmit,
    control,
    watch,
    formState: { errors },
  } = useForm<EventFormValues>({
    resolver: zodResolver(eventFormSchema),
    mode: "onSubmit",
    defaultValues: defaultValues
      ? {
          title: defaultValues.title,
          description: defaultValues.description ?? "",
          type: defaultValues.type,
          is_online: !!defaultValues.is_online,
          location: defaultValues.location ?? "",
          capacity: defaultValues.capacity,
          start_time: utcIsoToLocalDateTimeInput(defaultValues.start_time),
          end_time: utcIsoToLocalDateTimeInput(defaultValues.end_time),
          status: defaultValues.status,
        }
      : {
          title: "",
          description: "",
          type: undefined as any,
          is_online: false,
          location: "",
          capacity: undefined as any,
          start_time: "",
          end_time: "",
          status: "draft",
        },
  });

  const isOnline = watch("is_online");

  const submitHandler = (values: EventFormValues) => {
    const payload: CreateEventPayload = {
      title: values.title,
      description: values.description || undefined,
      type: values.type as CreateEventPayload["type"],
      is_online: values.is_online,
      location: values.location || undefined,
      capacity: values.capacity,
      start_time: localDateTimeToUtcIso(values.start_time),
      end_time: localDateTimeToUtcIso(values.end_time),
      status: values.status as CreateEventPayload["status"],
    };
    onSubmit(payload);
  };

  /**
   * Called by react-hook-form when handleSubmit's validation FAILS.
   * Without this, a validation failure is silent from the user's
   * perspective - the form just "does nothing" when Save is clicked,
   * which is indistinguishable from the onClick handler not firing at all.
   */
  const onInvalid = (formErrors: typeof errors) => {
    // eslint-disable-next-line no-console
    console.error("EventForm validation failed:", formErrors);
  };

  return (
    <form
      onSubmit={handleSubmit(submitHandler, onInvalid)}
      className="flex flex-col gap-4"
      noValidate
    >
      {Object.keys(errors).length > 0 && (
        <div className="rounded-lg border border-ember-200 bg-ember-50 p-3 text-sm text-ember-600">
          Please fix the highlighted fields below before saving.
        </div>
      )}

      <Input
        label="Title"
        error={errors.title?.message}
        {...register("title")}
      />

      <Textarea
        label="Description"
        error={errors.description?.message}
        {...register("description")}
      />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Select
          label="Event type"
          placeholder="Select a type"
          options={EVENT_TYPES}
          error={errors.type?.message}
          {...register("type")}
        />

        <Select
          label="Status"
          options={EVENT_STATUSES}
          error={errors.status?.message}
          {...register("status")}
        />
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Input
          label="Start date & time"
          type="datetime-local"
          error={errors.start_time?.message}
          {...register("start_time")}
        />
        <Input
          label="End date & time"
          type="datetime-local"
          error={errors.end_time?.message}
          {...register("end_time")}
        />
      </div>

      <Controller
        control={control}
        name="is_online"
        render={({ field }) => (
          <label className="flex items-center gap-2 text-sm font-medium text-ink-soft">
            <input
              type="checkbox"
              checked={field.value}
              onChange={(e) => field.onChange(e.target.checked)}
              className="h-4 w-4 rounded border-paper-line text-ember-500 focus:ring-ember-400"
            />
            This is a virtual / online event
          </label>
        )}
      />

      <Input
        label={isOnline ? "Meeting URL" : "Physical location"}
        placeholder={isOnline ? "https://zoom.us/j/..." : "123 Main St, City"}
        error={errors.location?.message}
        {...register("location")}
      />

      <Controller
        control={control}
        name="capacity"
        render={({ field }) => (
          <Input
            label="Maximum capacity"
            type="number"
            min={1}
            error={errors.capacity?.message}
            name={field.name}
            ref={field.ref}
            onBlur={field.onBlur}
            // Keep the input's displayed value as a string, but always
            // hand react-hook-form/Zod a NUMBER (or undefined while empty).
            // register('capacity', { valueAsNumber: true }) converts an
            // EMPTY string to NaN, and Zod's z.number() rejects NaN with
            // a generic error that often renders nowhere visible -
            // making the whole form's handleSubmit silently never call
            // onSubmit. Controller avoids that intermediate NaN state.
            value={field.value ?? ""}
            onChange={(e) => {
              const raw = e.target.value;
              field.onChange(raw === "" ? undefined : Number(raw));
            }}
          />
        )}
      />

      <Button
        type="submit"
        isLoading={isSubmitting}
        className="mt-2 w-full sm:w-auto"
      >
        {isSubmitting ? "Saving…" : submitLabel}
      </Button>
    </form>
  );
}
