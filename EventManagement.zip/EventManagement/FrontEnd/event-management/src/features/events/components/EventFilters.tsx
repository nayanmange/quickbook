import { useEffect, useState } from "react";
import { Search } from "lucide-react";
import { Input } from "../../../components/ui/Input";
import { Select } from "../../../components/ui/Select";
import { useDebounce } from "../../../hook/useDebounce";
import { EVENT_TYPES } from "../../../utils/constants";
import type {
  EventFilters as EventFiltersType,
  EventType,
} from "../../../types";

interface EventFiltersProps {
  filters: EventFiltersType;
  onChange: (filters: EventFiltersType) => void;
}

const TYPE_OPTIONS = EVENT_TYPES;

export function EventFilters({ filters, onChange }: EventFiltersProps) {
  // Local state so the input feels instant; debounced value drives the actual query
  const [searchInput, setSearchInput] = useState(filters.search ?? "");
  const debouncedSearch = useDebounce(searchInput, 500);

  useEffect(() => {
    if (debouncedSearch !== (filters.search ?? "")) {
      onChange({ ...filters, search: debouncedSearch || undefined, page: 1 });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedSearch]);

  return (
    <div className="grid grid-cols-1 gap-3 sm:grid-cols-[2fr_1fr_1fr_1fr]">
      <div className="relative">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
        <Input
          placeholder="Search events by title…"
          value={searchInput}
          onChange={(e) => setSearchInput(e.target.value)}
          className="pl-9"
          aria-label="Search events"
        />
      </div>

      <Select
        placeholder="All types"
        options={TYPE_OPTIONS}
        value={filters.type ?? ""}
        onChange={(e) =>
          onChange({
            ...filters,
            type: (e.target.value || undefined) as EventType | undefined,
            page: 1,
          })
        }
        aria-label="Filter by event type"
      />

      <Input
        type="date"
        value={filters.from?.slice(0, 10) ?? ""}
        onChange={(e) =>
          onChange({
            ...filters,
            from: e.target.value
              ? new Date(e.target.value).toISOString()
              : undefined,
            page: 1,
          })
        }
        aria-label="From date"
      />

      <Input
        type="date"
        value={filters.to?.slice(0, 10) ?? ""}
        onChange={(e) =>
          onChange({
            ...filters,
            to: e.target.value
              ? new Date(e.target.value).toISOString()
              : undefined,
            page: 1,
          })
        }
        aria-label="To date"
      />
    </div>
  );
}
