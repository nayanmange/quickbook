import { useParams, useNavigate } from "react-router-dom";
import { ErrorBoundary } from "react-error-boundary";
import { Card, CardBody } from "../../../components/ui/Card";
import { EventForm } from "../components/EventForm";
import { EventDetailsSkeleton } from "../components/EventDetailsSkeleton";
import { QueryErrorFallback } from "../../../components/QueryErrorFallback";
import { useEvent } from "../hooks/useEvent";
import { useUpdateEvent } from "../hooks/useUpdateEvent";
import { ROUTES } from "../../../utils/constants";

export default function EditEventPage() {
  const { id } = useParams<{ id: string }>();
  const eventId = Number(id);

  return (
    <ErrorBoundary FallbackComponent={QueryErrorFallback}>
      <EditEventContent eventId={eventId} />
    </ErrorBoundary>
  );
}

function EditEventContent({ eventId }: { eventId: number }) {
  const {
    data: event,
    isLoading,
    isError,
    error,
  } = useEvent(eventId, { poll: false });

  const navigate = useNavigate();
  const { mutate, isPending } = useUpdateEvent(eventId);

  if (isLoading || isNaN(eventId)) return <EventDetailsSkeleton />;
  if (isError) throw error;
  if (!event) return null;

  const handleSubmit = (payload: any) => {
    mutate(payload, {
      onSuccess: () => {
        navigate(ROUTES.EVENT_DETAILS(eventId));
      },
    });
  };

  return (
    <div className="mx-auto max-w-2xl">
      <h1 className="mb-6 text-2xl font-bold text-slate-900">Edit Event</h1>
      <Card>
        <CardBody>
          <EventForm
            defaultValues={event}
            onSubmit={handleSubmit}
            isSubmitting={isPending}
            submitLabel="Save changes"
          />
        </CardBody>
      </Card>
    </div>
  );
}
