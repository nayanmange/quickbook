import { useState } from "react";
import { CalendarSearch } from "lucide-react";
import { ErrorBoundary } from "react-error-boundary";
import { EventCard } from "../components/EventCard";
import { EventFilters } from "../components/EventFilters";
import { EventListSkeleton } from "../components/EventListSkeleton";
import { EmptyState } from "../../../components/ui/EmptyState";
import { Pagination } from "../../../components/ui/Pagination";
import { QueryErrorFallback } from "../../../components/QueryErrorFallback";
import { useEvents } from "../hooks/useEvents";
import { DEFAULT_PAGE_SIZE } from "../../../utils/constants";
import type { EventFilters as EventFiltersType } from "../../../types";

export default function EventDiscoveryPage() {
  const [filters, setFilters] = useState<EventFiltersType>({
    page: 1,
    limit: DEFAULT_PAGE_SIZE,
    status: "published",
  });

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Discover Events</h1>
        <p className="mt-1 text-sm text-slate-500">
          Browse upcoming conferences, workshops, webinars, and more.
        </p>
      </div>

      <EventFilters filters={filters} onChange={setFilters} />

      <ErrorBoundary FallbackComponent={QueryErrorFallback}>
        <EventResults
          filters={filters}
          onPageChange={(page) => setFilters((f) => ({ ...f, page }))}
        />
      </ErrorBoundary>
    </div>
  );
}

function EventResults({
  filters,
  onPageChange,
}: {
  filters: EventFiltersType;
  onPageChange: (page: number) => void;
}) {
  const { data, isLoading, isError, error } = useEvents(filters);

  if (isLoading) return <EventListSkeleton />;

  // Let the boundary handle render-time throw for non-loading errors
  if (isError) throw error;

  if (!data || data.data.length === 0) {
    return (
      <EmptyState
        icon={<CalendarSearch className="h-12 w-12" />}
        title="No events found"
        description="Try adjusting your search or filters to find what you're looking for."
      />
    );
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {data.data.map((event) => (
          <EventCard key={event.id} event={event} />
        ))}
      </div>
      <Pagination pagination={data.pagination} onPageChange={onPageChange} />
    </div>
  );
}
