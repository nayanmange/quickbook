import { useState } from "react";
import { Link } from "react-router-dom";
import { Plus, CalendarPlus, Pencil, Users, Trash2 } from "lucide-react";
import { ErrorBoundary } from "react-error-boundary";
import { Card, CardBody } from "../../../components/ui/Card";
import { Badge } from "../../../components/ui/Badge";
import { Button } from "../../../components/ui/Button";
import { EmptyState } from "../../../components/ui/EmptyState";
import { Pagination } from "../../../components/ui/Pagination";
import { Skeleton } from "../../../components/ui/Skeleton";
import { Modal } from "../../../components/ui/Modal";
import { QueryErrorFallback } from "../../../components/QueryErrorFallback";
import { useMyEvents } from "../hooks/useMyEvents";
import { useDeleteEvent } from "../hooks/useDeleteEvent";
import { formatDateTime } from "../../../utils/formatDate";
import {
  DEFAULT_PAGE_SIZE,
  EVENT_TYPES,
  ROUTES,
} from "../../../utils/constants";
import type { Event } from "../../../types";

const TYPE_LABELS = Object.fromEntries(
  EVENT_TYPES.map((t) => [t.value, t.label]),
);
const STATUS_VARIANT = {
  draft: "default",
  published: "success",
  cancelled: "danger",
  completed: "info",
} as const;

export default function EventManagementPage() {
  const [page, setPage] = useState(1);

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">My Events</h1>
          <p className="mt-1 text-sm text-slate-500">
            Manage events you're organizing.
          </p>
        </div>
        <Link to={ROUTES.CREATE_EVENT}>
          <Button>
            <Plus className="h-4 w-4" />
            New event
          </Button>
        </Link>
      </div>

      <ErrorBoundary FallbackComponent={QueryErrorFallback}>
        <EventsList page={page} onPageChange={setPage} />
      </ErrorBoundary>
    </div>
  );
}

function EventsList({
  page,
  onPageChange,
}: {
  page: number;
  onPageChange: (p: number) => void;
}) {
  const { data, isLoading, isError, error } = useMyEvents({
    page,
    limit: DEFAULT_PAGE_SIZE,
  });
  const deleteMutation = useDeleteEvent();
  const [eventToCancel, setEventToCancel] = useState<Event | null>(null);

  if (isLoading) {
    return (
      <div className="flex flex-col gap-2">
        {Array.from({ length: 4 }).map((_, i) => (
          <Skeleton key={i} className="h-20 rounded-xl" />
        ))}
      </div>
    );
  }

  if (isError) throw error;

  if (!data || data.data.length === 0) {
    return (
      <EmptyState
        icon={<CalendarPlus className="h-12 w-12" />}
        title="No events yet"
        description="Create your first event to start accepting registrations."
        action={
          <Link to={ROUTES.CREATE_EVENT}>
            <Button>
              <Plus className="h-4 w-4" />
              Create event
            </Button>
          </Link>
        }
      />
    );
  }

  const confirmCancel = () => {
    if (!eventToCancel) return;
    deleteMutation.mutate(eventToCancel.id, {
      onSettled: () => setEventToCancel(null),
    });
  };

  return (
    <>
      <div className="flex flex-col gap-3">
        {data.data.map((event) => (
          <Card key={event.id}>
            <CardBody className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-2">
                  <Badge variant="info">
                    {TYPE_LABELS[event.type] ?? event.type}
                  </Badge>
                  <Badge variant={STATUS_VARIANT[event.status]}>
                    {event.status}
                  </Badge>
                </div>
                <h3 className="font-semibold text-slate-900">{event.title}</h3>
                <p className="text-sm text-slate-500">
                  {formatDateTime(event.start_time)} · {event.registered_count}/
                  {event.capacity} registered
                </p>
              </div>

              <div className="flex gap-2">
                <Link to={ROUTES.EVENT_ATTENDEES(event.id)}>
                  <Button variant="secondary" size="sm">
                    <Users className="h-4 w-4" />
                    Attendees
                  </Button>
                </Link>
                <Link to={ROUTES.EDIT_EVENT(event.id)}>
                  <Button variant="secondary" size="sm">
                    <Pencil className="h-4 w-4" />
                    Edit
                  </Button>
                </Link>
                <Button
                  variant="danger"
                  size="sm"
                  onClick={() => setEventToCancel(event)}
                >
                  <Trash2 className="h-4 w-4" />
                  Delete
                </Button>
              </div>
            </CardBody>
          </Card>
        ))}
      </div>

      <Pagination pagination={data.pagination} onPageChange={onPageChange} />

      <Modal
        isOpen={!!eventToCancel}
        onClose={() => setEventToCancel(null)}
        title="Delete event"
      >
        <p className="text-sm text-slate-600">
          Are you sure you want to delete{" "}
          <strong>{eventToCancel?.title}</strong>? This action cannot be undone,
          and any registered participants will lose access.
        </p>
        <div className="mt-4 flex justify-end gap-2">
          <Button variant="secondary" onClick={() => setEventToCancel(null)}>
            Cancel
          </Button>
          <Button
            variant="danger"
            isLoading={deleteMutation.isPending}
            onClick={confirmCancel}
          >
            Delete event
          </Button>
        </div>
      </Modal>
    </>
  );
}
