import { useParams } from "react-router-dom";
import { ErrorBoundary } from "react-error-boundary";
import { Calendar, Clock, MapPin, Users, Video } from "lucide-react";
import { Card, CardBody } from "../../../components/ui/Card";
import { Badge } from "../../../components/ui/Badge";
import { QueryErrorFallback } from "../../../components/QueryErrorFallback";
import { EventDetailsSkeleton } from "../components/EventDetailsSkeleton";
import { useEvent } from "../hooks/useEvent";
import { formatDateTime, getUserTimezone } from "../../../utils/formatDate";
import { getEventAvailability } from "../utils/eventAvailability";
import { EVENT_TYPES } from "../../../utils/constants";
import { RegisterButton } from "../../registrations/components/RegisterButton";

const TYPE_LABELS = Object.fromEntries(
  EVENT_TYPES.map((t) => [t.value, t.label]),
);

export default function EventDetailsPage() {
  const { id } = useParams<{ id: string }>();
  const eventId = Number(id);

  return (
    <ErrorBoundary FallbackComponent={QueryErrorFallback}>
      <EventDetailsContent eventId={eventId} />
    </ErrorBoundary>
  );
}

function EventDetailsContent({ eventId }: { eventId: number }) {
  // Polls every 30s so capacity stays live while the user views this page
  const {
    data: event,
    isLoading,
    isError,
    error,
  } = useEvent(eventId, { poll: true });

  if (isLoading) return <EventDetailsSkeleton />;
  if (isError) throw error;
  if (!event) return null;

  const availability = getEventAvailability(event);

  return (
    <div className="mx-auto max-w-3xl">
      <Badge variant="info" className="mb-3">
        {TYPE_LABELS[event.type] ?? event.type}
      </Badge>

      <h1 className="text-3xl font-bold text-slate-900">{event.title}</h1>

      <p className="mt-2 text-sm text-slate-500">
        Times shown in your local timezone ({getUserTimezone()})
      </p>

      <Card className="mt-6">
        <CardBody className="flex flex-col gap-4">
          {event.description && (
            <p className="text-slate-700">{event.description}</p>
          )}

          <DetailRow icon={<Calendar className="h-5 w-5" />} label="Starts">
            {formatDateTime(event.start_time)}
          </DetailRow>

          <DetailRow icon={<Clock className="h-5 w-5" />} label="Ends">
            {formatDateTime(event.end_time)}
          </DetailRow>

          <DetailRow
            icon={
              event.is_online ? (
                <Video className="h-5 w-5" />
              ) : (
                <MapPin className="h-5 w-5" />
              )
            }
            label={event.is_online ? "Join link" : "Location"}
          >
            {event.is_online ? (
              <a
                href={event.location ?? "#"}
                target="_blank"
                rel="noopener noreferrer"
                className="text-indigo-600 hover:underline"
              >
                {event.location}
              </a>
            ) : (
              event.location
            )}
          </DetailRow>

          <DetailRow icon={<Users className="h-5 w-5" />} label="Capacity">
            {event.registered_count} / {event.capacity} registered
            {availability.kind === "available" && (
              <span className="ml-2 text-emerald-600">
                ({availability.seatsRemaining} seats left)
              </span>
            )}
          </DetailRow>

          <div className="pt-2">
            <RegisterButton event={event} />
          </div>
        </CardBody>
      </Card>
    </div>
  );
}

function DetailRow({
  icon,
  label,
  children,
}: {
  icon: React.ReactNode;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-start gap-3">
      <div className="mt-0.5 text-slate-400">{icon}</div>
      <div>
        <p className="text-xs font-medium uppercase tracking-wide text-slate-400">
          {label}
        </p>
        <div className="text-sm text-slate-700">{children}</div>
      </div>
    </div>
  );
}
