import { Card, CardBody } from "../../../components/ui/Card";
import { EventForm } from "../components/EventForm";
import { useCreateEvent } from "../hooks/useCreateEvent";

export default function CreateEventPage() {
  const { mutate, isPending } = useCreateEvent();

  return (
    <div className="mx-auto max-w-2xl">
      <h1 className="mb-6 text-2xl font-bold text-slate-900">Create Event</h1>
      <Card>
        <CardBody>
          <EventForm
            onSubmit={(payload) => mutate(payload)}
            isSubmitting={isPending}
            submitLabel="Create event"
          />
        </CardBody>
      </Card>
    </div>
  );
}
