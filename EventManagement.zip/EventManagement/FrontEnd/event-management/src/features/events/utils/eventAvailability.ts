import type { Event, EventAvailability } from "../../../types";

/**
 * Pure function deriving the capacity UI state from raw event data.
 * Returns a discriminated union so consumers must handle every case.
 */
export function getEventAvailability(event: Event): EventAvailability {
  const seatsRemaining = event.capacity - event.registered_count;

  if (seatsRemaining > 0) {
    return { kind: "available", seatsRemaining };
  }

  // At/over capacity — still allow waitlist sign-ups for published events
  if (event.status === "published") {
    return { kind: "waitlist_open" };
  }

  return { kind: "sold_out" };
}

export function isEventInPast(event: Event): boolean {
  return new Date(event.end_time).getTime() < Date.now();
}

export function isEventUpcoming(event: Event): boolean {
  return new Date(event.start_time).getTime() > Date.now();
}
