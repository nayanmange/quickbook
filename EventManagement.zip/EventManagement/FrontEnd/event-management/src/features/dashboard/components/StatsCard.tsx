import type { ReactNode } from "react";
import { Card, CardBody } from "../../../components/ui/Card";
import { cn } from "../../../lib/cn";

interface StatsCardProps {
  label: string;
  value: string | number;
  icon: ReactNode;
  accent?: "indigo" | "emerald" | "amber";
}

const ACCENT_STYLES: Record<NonNullable<StatsCardProps["accent"]>, string> = {
  indigo: "bg-indigo-50 text-indigo-600",
  emerald: "bg-emerald-50 text-emerald-600",
  amber: "bg-amber-50 text-amber-600",
};

export function StatsCard({
  label,
  value,
  icon,
  accent = "indigo",
}: StatsCardProps) {
  return (
    <Card>
      <CardBody className="flex items-center gap-4">
        <div
          className={cn(
            "flex h-12 w-12 items-center justify-center rounded-lg",
            ACCENT_STYLES[accent],
          )}
        >
          {icon}
        </div>
        <div>
          <p className="text-sm text-slate-500">{label}</p>
          <p className="text-2xl font-bold text-slate-900">{value}</p>
        </div>
      </CardBody>
    </Card>
  );
}
