import { useMemo } from "react";
import { useMyEvents } from "../../events/hooks/useMyEvents";
import { isEventUpcoming } from "../../events/utils/eventAvailability";

/**
 * Derives aggregate dashboard metrics client-side from the organizer's
 * events list. Fetches a large page size since this is a summary view
 * over (typically) a small/medium dataset.
 *
 * Trade-off note: for organizers with very large event counts, this
 * should be replaced by a dedicated GET /organizer/stats endpoint that
 * computes aggregates in SQL rather than in the browser.
 */
export function useDashboardStats() {
  const { data, isLoading, isError, error } = useMyEvents({
    page: 1,
    limit: 100,
  });

  const stats = useMemo(() => {
    if (!data) return null;

    const events = data.data;
    const upcomingEvents = events.filter(
      (e) => isEventUpcoming(e) && e.status === "published",
    );

    const totalRegistrations = events.reduce(
      (sum, e) => sum + e.registered_count,
      0,
    );
    const totalCapacity = events.reduce((sum, e) => sum + e.capacity, 0);
    const capacityFilledPct =
      totalCapacity > 0
        ? Math.round((totalRegistrations / totalCapacity) * 100)
        : 0;

    return {
      totalUpcomingEvents: upcomingEvents.length,
      totalRegistrations,
      capacityFilledPct,
      totalEvents: data.pagination.total,
    };
  }, [data]);

  return { stats, isLoading, isError, error };
}
