import { Link } from "react-router-dom";
import { ErrorBoundary } from "react-error-boundary";
import {
  CalendarClock,
  Users,
  PieChart,
  Plus,
  CalendarPlus,
} from "lucide-react";
import { StatsCard } from "../components/StatsCard";
import { DashboardSkeleton } from "../components/DashboardSkeleton";
import { Button } from "../../../components/ui/Button";
import { EmptyState } from "../../../components/ui/EmptyState";
import { QueryErrorFallback } from "../../../components/QueryErrorFallback";
import { useDashboardStats } from "../hooks/useDashboardStats";
import { ROUTES } from "../../../utils/constants";

export default function OrganizerDashboardPage() {
  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Dashboard</h1>
          <p className="mt-1 text-sm text-slate-500">
            An overview of your events and engagement.
          </p>
        </div>
        <Link to={ROUTES.CREATE_EVENT}>
          <Button>
            <Plus className="h-4 w-4" />
            New event
          </Button>
        </Link>
      </div>

      <ErrorBoundary FallbackComponent={QueryErrorFallback}>
        <DashboardStats />
      </ErrorBoundary>
    </div>
  );
}

function DashboardStats() {
  const { stats, isLoading, isError, error } = useDashboardStats();

  if (isLoading) return <DashboardSkeleton />;
  if (isError) throw error;

  if (!stats || stats.totalEvents === 0) {
    return (
      <EmptyState
        icon={<CalendarPlus className="h-12 w-12" />}
        title="Welcome! Let's create your first event"
        description="Once you create events, your analytics will appear here."
        action={
          <Link to={ROUTES.CREATE_EVENT}>
            <Button>
              <Plus className="h-4 w-4" />
              Create event
            </Button>
          </Link>
        }
      />
    );
  }

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
      <StatsCard
        label="Upcoming events"
        value={stats.totalUpcomingEvents}
        icon={<CalendarClock className="h-6 w-6" />}
        accent="indigo"
      />
      <StatsCard
        label="Total registrations"
        value={stats.totalRegistrations}
        icon={<Users className="h-6 w-6" />}
        accent="emerald"
      />
      <StatsCard
        label="Capacity filled"
        value={`${stats.capacityFilledPct}%`}
        icon={<PieChart className="h-6 w-6" />}
        accent="amber"
      />
    </div>
  );
}
