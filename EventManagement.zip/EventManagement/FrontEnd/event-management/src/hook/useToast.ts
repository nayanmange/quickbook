import toast from "react-hot-toast";
import type { AppApiError } from "../types";

export function useToast() {
  return {
    success: (message: string) => toast.success(message),
    error: (err: unknown) => {
      const apiErr = err as AppApiError;
      const message = apiErr?.message || "Something went wrong";
      toast.error(message);
    },
    info: (message: string) => toast(message),
  };
}
