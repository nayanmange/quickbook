/**
 * Renders nothing but throws a 404 Response, which is caught by the
 * nearest route's errorElement (RouteErrorBoundary). Used as the
 * catch-all "*" route so unmatched paths show the 404 UI consistently
 * with other route-loader errors.
 */
export default function NotFound(): never {
  throw new Response("Not Found", { status: 404 });
}
