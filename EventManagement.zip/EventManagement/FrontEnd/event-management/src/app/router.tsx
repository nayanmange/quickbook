// ============================================
// src/app/router.tsx
// ============================================

/* eslint-disable react-refresh/only-export-components --
   This file's purpose is to export the router configuration object,
   not React components. JSX appears only as route `element` values,
   which react-refresh's heuristic flags as a "component export"
   alongside the non-component `router` export. Fast refresh for the
   individual page components is unaffected since they live in their
   own files and are lazy-loaded. */

import { createBrowserRouter, Navigate } from "react-router-dom";
import { lazy } from "react";
import { AppLayout } from "../components/layout/AppLayout";
import { ProtectedRoute } from "../components/ProtectedRoute";
import { GuestRoute } from "../components/GuestRoute";
import { RouteErrorBoundary } from "./ErrorBoundary";
import NotFound from "./NotFound";
import { ROUTES } from "../utils/constants";

// --- Lazy-loaded pages (code-split per route) ---
const LoginPage = lazy(() => import("../features/auth/pages/LoginPage"));
const RegisterPage = lazy(() => import("../features/auth/pages/RegisterPage"));

const EventDiscoveryPage = lazy(
  () => import("../features/events/pages/EventDiscoveryPage"),
);
const EventDetailsPage = lazy(
  () => import("../features/events/pages/EventDetailsPage"),
);
const CreateEventPage = lazy(
  () => import("../features/events/pages/CreateEventPage"),
);
const EditEventPage = lazy(
  () => import("../features/events/pages/EditEventPage"),
);
const EventManagementPage = lazy(
  () => import("../features/events/pages/EventManagementPage"),
);

const MyTicketsPage = lazy(
  () => import("../features/registrations/pages/MyTicketsPage"),
);
const EventAttendeesPage = lazy(
  () => import("../features/registrations/pages/EventAttendeesPage"),
);

const OrganizerDashboardPage = lazy(
  () => import("../features/dashboard/pages/OrganizerDashboardPage"),
);

export const router = createBrowserRouter([
  {
    path: "/",
    element: <AppLayout />,
    errorElement: <RouteErrorBoundary />,
    children: [
      // --- Default redirect ---
      { index: true, element: <Navigate to={ROUTES.DISCOVER} replace /> },

      // --- Guest-only routes ---
      {
        element: <GuestRoute />,
        children: [
          { path: "login", element: <LoginPage /> },
          { path: "register", element: <RegisterPage /> },
        ],
      },

      // --- Public + Participant routes ---
      { path: "events", element: <EventDiscoveryPage /> },
      { path: "events/:id", element: <EventDetailsPage /> },

      {
        element: (
          <ProtectedRoute
            allowedRoles={["participant", "organizer", "admin"]}
          />
        ),
        children: [{ path: "my-tickets", element: <MyTicketsPage /> }],
      },

      // --- Organizer-only routes ---
      {
        path: "organizer",
        element: <ProtectedRoute allowedRoles={["organizer", "admin"]} />,
        children: [
          { index: true, element: <OrganizerDashboardPage /> },
          { path: "events", element: <EventManagementPage /> },
          { path: "events/new", element: <CreateEventPage /> },
          { path: "events/:id/edit", element: <EditEventPage /> },
          { path: "events/:id/attendees", element: <EventAttendeesPage /> },
        ],
      },

      // --- Catch-all 404 ---
      { path: "*", element: <NotFound /> },
    ],
  },
]);
