import { RouterProvider } from "react-router-dom";
import { QueryClientProvider } from "@tanstack/react-query";
import { ReactQueryDevtools } from "@tanstack/react-query-devtools";
import { Toaster } from "react-hot-toast";
import { router } from "./router";
import { queryClient } from "../lib/queryClient";
import { useAuthBootstrap } from "../features/auth/hooks/useAuth";
import { FullScreenSpinner } from "../components/ui/Spinner";
import { useAuthStore } from "../features/auth/store/authStore";

function AuthGate({ children }: { children: React.ReactNode }) {
  useAuthBootstrap();
  const hasHydrated = useAuthStore(
    (s: { hasHydrated: unknown }) => s.hasHydrated,
  );

  if (!hasHydrated) return <FullScreenSpinner />;
  return <>{children}</>;
}

export function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthGate>
        <RouterProvider router={router} />
      </AuthGate>
      <Toaster position="top-right" />
      {import.meta.env.DEV && <ReactQueryDevtools initialIsOpen={false} />}
    </QueryClientProvider>
  );
}
