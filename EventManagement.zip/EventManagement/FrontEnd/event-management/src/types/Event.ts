export type EventType =
  | 'conference'
  | 'workshop'
  | 'webinar'
  | 'meetup'
  | 'training'
  | 'corporate';

export type EventStatus = 'draft' | 'published' | 'cancelled' | 'completed';

export interface Event {
  id: number;
  organizer_id: number;
  title: string;
  description: string | null;
  type: EventType;
  location: string | null;
  is_online: boolean;
  capacity: number;
  registered_count: number;
  start_time: string; // ISO 8601 UTC string from API
  end_time: string;   // ISO 8601 UTC string from API
  status: EventStatus;
  created_at: string;
  updated_at: string;
}

/**
 * Derived, client-only view of an event's capacity state.
 * Computed via a selector — never trusted directly from a stale cache entry.
 */
export type EventAvailability =
  | { kind: 'available'; seatsRemaining: number }
  | { kind: 'sold_out' }
  | { kind: 'waitlist_open' };

export interface CreateEventPayload {
  title: string;
  description?: string;
  type: EventType;
  location?: string;
  is_online: boolean;
  capacity: number;
  start_time: string; // ISO 8601, converted to UTC before sending
  end_time: string;
  status?: EventStatus;
}

export type UpdateEventPayload = Partial<CreateEventPayload>;

export interface EventFilters {
  page?: number;
  limit?: number;
  type?: EventType;
  status?: EventStatus;
  from?: string;
  to?: string;
  search?: string;
}