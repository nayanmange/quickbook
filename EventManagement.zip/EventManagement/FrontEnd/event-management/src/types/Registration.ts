export type RegistrationStatus = 'confirmed' | 'cancelled' | 'waitlisted';

export interface Registration {
  id: number;
  event_id: number;
  user_id: number;
  status: RegistrationStatus;
  registered_at: string;
  cancelled_at: string | null;
}

export interface RegistrationWithEvent extends Registration {
  event_title: string;
  event_start_time: string;
  event_end_time: string;
  event_status: string;
}

export interface AttendeeRegistration extends Registration {
  user_name: string;
  user_email: string;
}

/**
 * Discriminated union representing the participant's relationship
 * to a given event — drives RegisterButton's UI state.
 */
export type RegistrationState =
  | { status: 'not_registered' }
  | { status: 'confirmed'; registrationId: number }
  | { status: 'waitlisted'; registrationId: number }
  | { status: 'cancelled'; registrationId: number };