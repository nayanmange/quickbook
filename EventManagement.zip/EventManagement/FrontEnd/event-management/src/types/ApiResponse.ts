export interface ApiSuccessResponse<T> {
  status: "success";
  data: T;
  message?: string;
}

export interface ApiErrorResponse {
  status: "error";
  message: string;
  statusCode: number;
  errors?: Record<string, string[]>;
}

/**
 * Discriminated union for the shape of any API response body.
 * Used to narrow in axios error interceptors and error boundaries.
 */
export type ApiResponse<T> = ApiSuccessResponse<T> | ApiErrorResponse;

/**
 * Normalized error shape used throughout the app, regardless of
 * whether the failure came from the network, a 4xx, or a 5xx.
 */
export interface AppApiError {
  message: string;
  statusCode: number;
  errors?: Record<string, string[]>;
}
