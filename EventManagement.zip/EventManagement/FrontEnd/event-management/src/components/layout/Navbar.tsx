import { Link, NavLink } from "react-router-dom";
import {
  CalendarDays,
  Ticket,
  LayoutDashboard,
  CalendarPlus,
  LogOut,
  User,
} from "lucide-react";
import { cn } from "../../lib/cn";
import { useAuth } from "../../features/auth/hooks/useAuth";
import { useLogout } from "../../features/auth/hooks/useLogout";
import { Button } from "../ui/Button";
import { ROUTES } from "../../utils/constants";

const navLinkClasses = ({ isActive }: { isActive: boolean }) =>
  cn(
    "flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
    isActive
      ? "bg-indigo-50 text-indigo-700"
      : "text-slate-600 hover:bg-slate-100 hover:text-slate-900",
  );

export function Navbar() {
  const { isAuthenticated, user } = useAuth();
  const { mutate: logout, isPending: isLoggingOut } = useLogout();

  const isOrganizer = user?.role === "organizer" || user?.role === "admin";

  return (
    <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/80 backdrop-blur">
      <nav className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6 lg:px-8">
        <Link
          to={ROUTES.DISCOVER}
          className="flex items-center gap-2 font-bold text-slate-900"
        >
          <CalendarDays className="h-6 w-6 text-indigo-600" />
          <span className="hidden sm:inline">EventHub</span>
        </Link>

        <div className="flex items-center gap-1 overflow-x-auto">
          <NavLink to={ROUTES.DISCOVER} className={navLinkClasses}>
            <CalendarDays className="h-4 w-4" />
            <span className="hidden sm:inline">Discover</span>
          </NavLink>

          {isAuthenticated && !isOrganizer && (
            <NavLink to={ROUTES.MY_TICKETS} className={navLinkClasses}>
              <Ticket className="h-4 w-4" />
              <span className="hidden sm:inline">My Tickets</span>
            </NavLink>
          )}

          {isAuthenticated && isOrganizer && (
            <>
              <NavLink
                to={ROUTES.ORGANIZER_DASHBOARD}
                className={navLinkClasses}
                end
              >
                <LayoutDashboard className="h-4 w-4" />
                <span className="hidden sm:inline">Dashboard</span>
              </NavLink>
              <NavLink to={ROUTES.ORGANIZER_EVENTS} className={navLinkClasses}>
                <CalendarPlus className="h-4 w-4" />
                <span className="hidden sm:inline">My Events</span>
              </NavLink>
            </>
          )}
        </div>

        <div className="flex items-center gap-3">
          {isAuthenticated && user ? (
            <>
              <div className="hidden items-center gap-2 text-sm text-slate-600 sm:flex">
                <User className="h-4 w-4" />
                <span className="max-w-[140px] truncate">{user.name}</span>
              </div>
              <Button
                variant="ghost"
                size="sm"
                isLoading={isLoggingOut}
                onClick={() => logout()}
                aria-label="Log out"
              >
                <LogOut className="h-4 w-4" />
                <span className="hidden sm:inline">Log out</span>
              </Button>
            </>
          ) : (
            <div className="flex items-center gap-2">
              <Link to={ROUTES.LOGIN}>
                <Button variant="ghost" size="sm">
                  Sign in
                </Button>
              </Link>
              <Link to={ROUTES.REGISTER}>
                <Button size="sm">Sign up</Button>
              </Link>
            </div>
          )}
        </div>
      </nav>
    </header>
  );
}
