import { useNavigation } from "react-router-dom";

/**
 * Indeterminate progress bar shown during route loader/lazy-chunk
 * transitions, driven by React Router's navigation state.
 */
export function TopBarLoader() {
  const navigation = useNavigation();
  const isLoading = navigation.state === "loading";

  if (!isLoading) return null;

  return (
    <div className="fixed top-0 left-0 z-50 h-1 w-full overflow-hidden bg-transparent">
      <div className="h-full w-full origin-left animate-[loading-bar_1.2s_ease-in-out_infinite] bg-indigo-600" />
    </div>
  );
}
