import { Outlet } from "react-router-dom";
import { Suspense } from "react";
import { Navbar } from "./Navbar";
import { TopBarLoader } from "./TopBarLoader";
import { FullScreenSpinner } from "../ui/Spinner";

export function AppLayout() {
  return (
    <div className="min-h-screen bg-slate-50">
      <TopBarLoader />
      <Navbar />
      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
        <Suspense fallback={<FullScreenSpinner />}>
          <Outlet />
        </Suspense>
      </main>
    </div>
  );
}
