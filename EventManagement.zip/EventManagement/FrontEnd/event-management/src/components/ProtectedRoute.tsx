import { Navigate, Outlet, useLocation } from "react-router-dom";
import { useAuth } from "../features/auth/hooks/useAuth";
import type { UserRole } from "../types";
import { FullScreenSpinner } from "./ui/Spinner";
import { ROUTES } from "../utils/constants";

interface ProtectedRouteProps {
  allowedRoles?: UserRole[];
}

/**
 * Guards a route subtree:
 * - Waits for session hydration before making any redirect decision.
 * - Redirects unauthenticated users to /login (preserving intended path).
 * - Redirects authenticated users lacking the required role to a
 *   role-appropriate landing page (not /login — they ARE logged in).
 */
export function ProtectedRoute({ allowedRoles }: ProtectedRouteProps) {
  const { isAuthenticated, hasHydrated, user } = useAuth();
  const location = useLocation();

  if (!hasHydrated) {
    return <FullScreenSpinner />;
  }

  if (!isAuthenticated || !user) {
    return <Navigate to={ROUTES.LOGIN} state={{ from: location }} replace />;
  }

  if (allowedRoles && !allowedRoles.includes(user.role)) {
    const fallback =
      user.role === "organizer" ? ROUTES.ORGANIZER_DASHBOARD : ROUTES.DISCOVER;
    return <Navigate to={fallback} replace />;
  }

  return <Outlet />;
}
