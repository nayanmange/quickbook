import { Navigate, Outlet } from "react-router-dom";
import { useAuth } from "../features/auth/hooks/useAuth";
import { FullScreenSpinner } from "./ui/Spinner";
import { ROUTES } from "../utils/constants";

/**
 * Guards /login and /register — redirects already-authenticated
 * users straight to their role-based home.
 */
export function GuestRoute() {
  const { isAuthenticated, hasHydrated, user } = useAuth();

  if (!hasHydrated) return <FullScreenSpinner />;

  if (isAuthenticated && user) {
    const home =
      user.role === "organizer" ? ROUTES.ORGANIZER_DASHBOARD : ROUTES.DISCOVER;
    return <Navigate to={home} replace />;
  }

  return <Outlet />;
}
