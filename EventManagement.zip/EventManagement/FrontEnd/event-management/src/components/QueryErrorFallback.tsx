import type { FallbackProps } from "react-error-boundary";
import { Button } from "./ui/Button";

/**
 * Used with <ErrorBoundary> from react-error-boundary, scoped around
 * individual feature trees (e.g. dashboard widgets) so one failing
 * query doesn't crash the whole page.
 */
export function QueryErrorFallback({
  error,
  resetErrorBoundary,
}: FallbackProps) {
  const message = error?.message || "Failed to load this section";

  return (
    <div className="flex flex-col items-center justify-center gap-3 rounded-lg border border-red-100 bg-red-50 p-6 text-center">
      <p className="text-sm font-medium text-red-700">{message}</p>
      <Button size="sm" variant="secondary" onClick={resetErrorBoundary}>
        Try again
      </Button>
    </div>
  );
}
