/**
 * Converts a UTC ISO string from the API into the user's local timezone
 * for display. Uses Intl.DateTimeFormat — no extra date library needed.
 */
export function formatDateTime(utcIsoString: string): string {
  const date = new Date(utcIsoString);
  return new Intl.DateTimeFormat(undefined, {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(date);
}

export function formatDate(utcIsoString: string): string {
  const date = new Date(utcIsoString);
  return new Intl.DateTimeFormat(undefined, { dateStyle: "medium" }).format(
    date,
  );
}

export function formatTime(utcIsoString: string): string {
  const date = new Date(utcIsoString);
  return new Intl.DateTimeFormat(undefined, { timeStyle: "short" }).format(
    date,
  );
}

/** Returns the user's IANA timezone, e.g. "Asia/Kolkata" */
export function getUserTimezone(): string {
  return Intl.DateTimeFormat().resolvedOptions().timeZone;
}

/**
 * Converts a "local datetime" value from an <input type="datetime-local">
 * (which has NO timezone info) into a UTC ISO string for the API.
 */
export function localDateTimeToUtcIso(localDateTimeValue: string): string {
  // `new Date("2026-06-14T10:00")` is parsed as LOCAL time by JS engines
  const localDate = new Date(localDateTimeValue);
  return localDate.toISOString();
}

/**
 * Converts a UTC ISO string from the API into the format required by
 * <input type="datetime-local"> (YYYY-MM-DDTHH:mm), in local time.
 */
export function utcIsoToLocalDateTimeInput(utcIsoString: string): string {
  const date = new Date(utcIsoString);
  const offset = date.getTimezoneOffset();
  const local = new Date(date.getTime() - offset * 60 * 1000);
  return local.toISOString().slice(0, 16);
}

/** Relative time, e.g. "in 2 hours" / "3 days ago" */
export function formatRelativeTime(utcIsoString: string): string {
  const date = new Date(utcIsoString);
  const diffMs = date.getTime() - Date.now();
  const diffMins = Math.round(diffMs / 60000);

  const rtf = new Intl.RelativeTimeFormat(undefined, { numeric: "auto" });

  const absMins = Math.abs(diffMins);
  if (absMins < 60) return rtf.format(diffMins, "minute");

  const diffHours = Math.round(diffMins / 60);
  if (Math.abs(diffHours) < 24) return rtf.format(diffHours, "hour");

  const diffDays = Math.round(diffHours / 24);
  return rtf.format(diffDays, "day");
}
