import type { EventType, EventStatus } from "../types";

export const EVENT_TYPES: { value: EventType; label: string }[] = [
  { value: "conference", label: "Conference" },
  { value: "workshop", label: "Workshop" },
  { value: "webinar", label: "Webinar" },
  { value: "meetup", label: "Meetup" },
  { value: "training", label: "Training Session" },
  { value: "corporate", label: "Corporate Event" },
];

export const EVENT_STATUSES: { value: EventStatus; label: string }[] = [
  { value: "draft", label: "Draft" },
  { value: "published", label: "Published" },
  { value: "cancelled", label: "Cancelled" },
  { value: "completed", label: "Completed" },
];

export const DEFAULT_PAGE_SIZE = 10;

export const QUERY_KEYS = {
  events: "events",
  event: "event",
  myEvents: "myEvents",
  registrations: "registrations",
  myRegistrations: "myRegistrations",
  eventAttendees: "eventAttendees",
  dashboardStats: "dashboardStats",
  currentUser: "currentUser",
} as const;

export const ROUTES = {
  LOGIN: "/login",
  REGISTER: "/register",
  DISCOVER: "/events",
  EVENT_DETAILS: (id: number | string) => `/events/${id}`,
  MY_TICKETS: "/my-tickets",
  ORGANIZER_DASHBOARD: "/organizer",
  ORGANIZER_EVENTS: "/organizer/events",
  CREATE_EVENT: "/organizer/events/new",
  EDIT_EVENT: (id: number | string) => `/organizer/events/${id}/edit`,
  EVENT_ATTENDEES: (id: number | string) => `/organizer/events/${id}/attendees`,
} as const;
