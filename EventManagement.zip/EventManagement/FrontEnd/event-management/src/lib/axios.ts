import axios, { AxiosError, type InternalAxiosRequestConfig } from "axios";
import type { AppApiError, ApiErrorResponse } from "../types";
import { useAuthStore } from "../features/auth/store/authStore";

export const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || "/api",
  withCredentials: true, // sends the HttpOnly refresh-token cookie
  headers: { "Content-Type": "application/json" },
});

// --- Request interceptor: attach access token ---
api.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  const token = useAuthStore.getState().accessToken;
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// --- Response interceptor: normalize errors + handle 401 refresh ---

let isRefreshing = false;
let refreshSubscribers: Array<(token: string) => void> = [];

function onRefreshed(token: string) {
  refreshSubscribers.forEach((cb) => cb(token));
  refreshSubscribers = [];
}

api.interceptors.response.use(
  (response) => response,
  async (error: AxiosError<ApiErrorResponse>) => {
    const originalRequest = error.config as InternalAxiosRequestConfig & {
      _retry?: boolean;
    };

    // Attempt silent refresh on 401 (but not for auth endpoints themselves)
    if (
      error.response?.status === 401 &&
      !originalRequest._retry &&
      !originalRequest.url?.includes("/auth/")
    ) {
      if (isRefreshing) {
        // Queue the request until the in-flight refresh completes
        return new Promise((resolve, reject) => {
          refreshSubscribers.push((token: string) => {
            originalRequest.headers.Authorization = `Bearer ${token}`;
            originalRequest._retry = true;
            resolve(api(originalRequest));
          });
          // Safety timeout in case refresh never resolves
          setTimeout(() => reject(error), 10000);
        });
      }

      originalRequest._retry = true;
      isRefreshing = true;

      try {
        const { data } = await api.post("/auth/refresh");
        const newToken = data.data.accessToken as string;

        useAuthStore.getState().setAccessToken(newToken);
        onRefreshed(newToken);

        originalRequest.headers.Authorization = `Bearer ${newToken}`;
        return api(originalRequest);
      } catch (refreshError) {
        useAuthStore.getState().logout();
        window.location.href = "/login";
        return Promise.reject(
          normalizeError(refreshError as AxiosError<ApiErrorResponse>),
        );
      } finally {
        isRefreshing = false;
      }
    }

    return Promise.reject(normalizeError(error));
  },
);

/**
 * Converts any Axios error (API error response, network error, or
 * unexpected shape) into a consistent AppApiError for the UI layer.
 */
export function normalizeError(
  error: AxiosError<ApiErrorResponse>,
): AppApiError {
  if (error.response?.data) {
    return {
      message: error.response.data.message || "Something went wrong",
      statusCode: error.response.data.statusCode || error.response.status,
      errors: error.response.data.errors,
    };
  }

  if (error.request) {
    return {
      message: "Network error — please check your connection",
      statusCode: 0,
    };
  }

  return {
    message: error.message || "An unexpected error occurred",
    statusCode: 500,
  };
}
