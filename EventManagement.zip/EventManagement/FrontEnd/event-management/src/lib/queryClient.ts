import { QueryClient } from "@tanstack/react-query";
import type { AppApiError } from "../types";

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: (failureCount, error) => {
        const err = error as unknown as AppApiError;
        // Don't retry client errors (4xx) — only network/server errors
        if (err.statusCode >= 400 && err.statusCode < 500) return false;
        return failureCount < 2;
      },
      staleTime: 30_000, // 30s default freshness window
      refetchOnWindowFocus: true,
    },
    mutations: {
      retry: false,
    },
  },
});
