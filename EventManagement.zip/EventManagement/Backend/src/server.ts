import { createApp } from "./app";
import { env } from "./config/env";
import { testDbConnection } from "./config/database";
import { logger } from "./config/logger";

async function bootstrap(): Promise<void> {
  await testDbConnection();

  const app = createApp();

  app.listen(env.PORT, () => {
    logger.info(`Server running on port ${env.PORT} in ${env.NODE_ENV} mode`);
  });
}

bootstrap().catch((err) => {
  logger.error("Failed to start server", { error: err });
  process.exit(1);
});
