import { Response } from "express";
import { env, isProduction } from "../config/env";

const REFRESH_COOKIE_NAME = "refreshToken";

export function setRefreshTokenCookie(res: Response, token: string): void {
  res.cookie(REFRESH_COOKIE_NAME, token, {
    httpOnly: true,
    secure: isProduction, // requires HTTPS in production
    sameSite: "strict",
    domain: env.COOKIE_DOMAIN,
    path: "/api/auth", // scoped to auth routes only
    maxAge: env.JWT_REFRESH_EXPIRES_IN_MS,
  });
}

export function clearRefreshTokenCookie(res: Response): void {
  res.clearCookie(REFRESH_COOKIE_NAME, {
    httpOnly: true,
    secure: isProduction,
    sameSite: "strict",
    domain: env.COOKIE_DOMAIN,
    path: "/api/auth",
  });
}

export { REFRESH_COOKIE_NAME };
