import jwt, { SignOptions } from "jsonwebtoken";
import { env } from "../config/env";
import { JwtAccessPayload } from "../model/auth.model";

export function signAccessToken(
  payload: Omit<JwtAccessPayload, "type">,
): string {
  const fullPayload: JwtAccessPayload = { ...payload, type: "access" };
  const options: SignOptions = { expiresIn: env.JWT_ACCESS_EXPIRES_IN as any };
  return jwt.sign(fullPayload, env.JWT_ACCESS_SECRET, options);
}

export function verifyAccessToken(token: string): JwtAccessPayload {
  return jwt.verify(
    token,
    env.JWT_ACCESS_SECRET,
  ) as unknown as JwtAccessPayload;
}
