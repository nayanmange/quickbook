import { z } from "zod";

const eventTypeEnum = z.enum([
  "conference",
  "workshop",
  "webinar",
  "meetup",
  "training",
  "corporate",
]);

const eventStatusEnum = z.enum([
  "draft",
  "published",
  "cancelled",
  "completed",
]);

export const createEventSchema = z.object({
  body: z
    .object({
      title: z.string().min(3).max(200),
      description: z.string().max(5000).optional(),
      type: eventTypeEnum,
      location: z.string().max(255).optional(),
      is_online: z.boolean().optional().default(false),
      capacity: z.number().int().positive(),
      start_time: z
        .string()
        .datetime({ message: "start_time must be a valid ISO 8601 datetime" }),
      end_time: z
        .string()
        .datetime({ message: "end_time must be a valid ISO 8601 datetime" }),
      status: eventStatusEnum.optional(),
    })
    .refine((data) => new Date(data.end_time) > new Date(data.start_time), {
      message: "end_time must be after start_time",
      path: ["end_time"],
    }),
});

export const updateEventSchema = z.object({
  params: z.object({
    id: z.coerce.number().int().positive(),
  }),
  body: z
    .object({
      title: z.string().min(3).max(200).optional(),
      description: z.string().max(5000).optional(),
      type: eventTypeEnum.optional(),
      location: z.string().max(255).optional(),
      is_online: z.boolean().optional(),
      capacity: z.number().int().positive().optional(),
      start_time: z.string().datetime().optional(),
      end_time: z.string().datetime().optional(),
      status: eventStatusEnum.optional(),
    })
    .refine(
      (data) =>
        !data.start_time ||
        !data.end_time ||
        new Date(data.end_time) > new Date(data.start_time),
      { message: "end_time must be after start_time", path: ["end_time"] },
    ),
});

export const eventIdParamSchema = z.object({
  params: z.object({
    id: z.coerce.number().int().positive(),
  }),
});

export const listEventsQuerySchema = z.object({
  query: z.object({
    page: z.coerce.number().int().positive().optional().default(1),
    limit: z.coerce.number().int().positive().max(100).optional().default(10),
    type: eventTypeEnum.optional(),
    status: eventStatusEnum.optional(),
    from: z.string().datetime().optional(),
    to: z.string().datetime().optional(),
  }),
});

export type CreateEventDto = z.infer<typeof createEventSchema>["body"];
export type UpdateEventDto = z.infer<typeof updateEventSchema>["body"];
export type ListEventsQueryDto = z.infer<typeof listEventsQuerySchema>["query"];
