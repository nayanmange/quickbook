import { z } from "zod";

export const eventIdParamSchema2 = z.object({
  params: z.object({
    eventId: z.coerce.number().int().positive(),
  }),
});

export const listMyRegistrationsQuerySchema = z.object({
  query: z.object({
    page: z.coerce.number().int().positive().optional().default(1),
    limit: z.coerce.number().int().positive().max(100).optional().default(10),
    status: z.enum(["confirmed", "cancelled", "waitlisted"]).optional(),
  }),
});

export type ListMyRegistrationsQueryDto = z.infer<
  typeof listMyRegistrationsQuerySchema
>["query"];

export const eventRegistrationsQuerySchema = z.object({
  params: z.object({ eventId: z.coerce.number().int().positive() }),
  query: z.object({
    page: z.coerce.number().int().positive().optional().default(1),
    limit: z.coerce.number().int().positive().max(100).optional().default(10),
    status: z.enum(["confirmed", "cancelled", "waitlisted"]).optional(),
  }),
});
export type EventRegistrationsQueryDto = z.infer<
  typeof eventRegistrationsQuerySchema
>["query"];
