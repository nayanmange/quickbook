import { Request, Response, NextFunction } from "express";
import { ZodError } from "zod";
import { AppError } from "../utils/AppError";
import { ApiErrorResponse } from "../model/api-response.model";
import { logger } from "../config/logger";
import { isProduction } from "../config/env";

export function notFoundHandler(
  req: Request,
  res: Response,
  next: NextFunction,
): void {
  next(AppError.notFound(`Route ${req.method} ${req.originalUrl} not found`));
}

// Must be registered LAST, with 4 arguments so Express recognizes it as an error handler
export function globalErrorHandler(
  err: Error,
  req: Request,
  res: Response,
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  next: NextFunction,
): void {
  // Handle Zod validation errors
  if (err instanceof ZodError) {
    const fieldErrors: Record<string, string[]> = {};
    for (const issue of err.issues) {
      const path = issue.path.slice(1).join(".") || "value"; // strip 'body'/'query'/'params' prefix
      if (!fieldErrors[path]) fieldErrors[path] = [];
      fieldErrors[path].push(issue.message);
    }

    const response: ApiErrorResponse = {
      status: "error",
      message: "Validation failed",
      statusCode: 400,
      errors: fieldErrors,
    };
    res.status(400).json(response);
    return;
  }

  // Handle known operational errors
  if (err instanceof AppError) {
    if (err.statusCode >= 500) {
      logger.error(err.message, { stack: err.stack, path: req.originalUrl });
    }

    const response: ApiErrorResponse = {
      status: "error",
      message: err.message,
      statusCode: err.statusCode,
      ...(err.errors && { errors: err.errors }),
    };
    res.status(err.statusCode).json(response);
    return;
  }

  // Handle MySQL duplicate entry errors
  if ((err as any).code === "ER_DUP_ENTRY") {
    const response: ApiErrorResponse = {
      status: "error",
      message: "A record with these details already exists",
      statusCode: 409,
    };
    res.status(409).json(response);
    return;
  }

  // Unknown / programming errors
  logger.error("Unhandled error", {
    error: err.message,
    stack: err.stack,
    path: req.originalUrl,
  });

  const response: ApiErrorResponse = {
    status: "error",
    message: isProduction ? "Internal server error" : err.message,
    statusCode: 500,
    ...(!isProduction && ({ stack: err.stack } as any)),
  };
  res.status(500).json(response);
}
