import { Request, Response, NextFunction } from "express";
import { ZodSchema } from "zod";

/**
 * Validates req.body, req.query, and req.params against a Zod schema.
 * On success, replaces req.body/query/params with the parsed (and coerced/defaulted) values.
 * On failure, throws ZodError -> caught by global error handler.
 */
export const validate = (schema: ZodSchema) => {
  return (req: Request, res: Response, next: NextFunction): void => {
    const parsed = schema.parse({
      body: req.body,
      query: req.query,
      params: req.params,
    });

    if (parsed.body) req.body = parsed.body;
    if (parsed.query) req.query = parsed.query as any;
    if (parsed.params) req.params = parsed.params as any;

    next();
  };
};
