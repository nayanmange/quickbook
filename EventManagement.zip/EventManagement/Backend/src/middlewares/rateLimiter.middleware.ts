import rateLimit from "express-rate-limit";
import { env } from "../config/env";
import { ApiErrorResponse } from "../model/api-response.model";

export const authRateLimiter = rateLimit({
  windowMs: env.RATE_LIMIT_WINDOW_MS,
  max: env.RATE_LIMIT_MAX_AUTH,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    status: "error",
    message: "Too many requests, please try again later",
    statusCode: 429,
  } as ApiErrorResponse,
});
