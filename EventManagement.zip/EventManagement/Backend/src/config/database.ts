import mysql from "mysql2/promise";
import { PoolConnection } from "mysql2/promise";
import { env } from "./env";
import { logger } from "./logger";

export const pool = mysql.createPool({
  host: env.DB_HOST,
  port: env.DB_PORT,
  user: env.DB_USER,
  password: env.DB_PASSWORD,
  database: env.DB_NAME,
  waitForConnections: true,
  connectionLimit: env.DB_POOL_LIMIT,
  queueLimit: 0,
  timezone: "Z", // Treat all dates as UTC (no local conversion)
  dateStrings: false,
});

export async function withTransaction<T>(
  callback: (conn: PoolConnection) => Promise<T>,
): Promise<T> {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const result = await callback(conn);
    await conn.commit();
    return result;
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}

export async function testDbConnection(): Promise<void> {
  try {
    const conn = await pool.getConnection();
    await conn.ping();
    conn.release();
    logger.info("Database connection established successfully");
  } catch (err) {
    logger.error("Failed to connect to database", { error: err });
    throw err;
  }
}
