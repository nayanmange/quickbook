import winston from "winston";
import { isProduction } from "./env";

export const logger = winston.createLogger({
  level: isProduction ? "info" : "debug",
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    isProduction
      ? winston.format.json()
      : winston.format.combine(
          winston.format.colorize(),
          winston.format.printf(
            ({ timestamp, level, message, stack, ...meta }) => {
              const metaStr = Object.keys(meta).length
                ? JSON.stringify(meta)
                : "";
              return `${timestamp} [${level}]: ${message} ${stack || ""} ${metaStr}`;
            },
          ),
        ),
  ),
  transports: [new winston.transports.Console()],
});
