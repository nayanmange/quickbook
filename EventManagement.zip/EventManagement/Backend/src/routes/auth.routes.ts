import { Router } from "express";
import { authController } from "../controllers/auth.controller";
import { validate } from "../middlewares/validate.middleware";
import { registerSchema, loginSchema } from "../schemas/auth.schema";
import { authRateLimiter } from "../middlewares/rateLimiter.middleware";
import { catchAsync } from "../utils/catchAsync";

const router = Router();

// Rate limiting applied to all sensitive auth endpoints to mitigate brute-force attacks
router.post(
  "/register",
  authRateLimiter,
  validate(registerSchema),
  catchAsync((req, res) => authController.register(req, res)),
);

router.post(
  "/login",
  authRateLimiter,
  validate(loginSchema),
  catchAsync((req, res) => authController.login(req, res)),
);

router.post(
  "/refresh",
  authRateLimiter,
  catchAsync((req, res) => authController.refresh(req, res)),
);

router.post(
  "/logout",
  catchAsync((req, res) => authController.logout(req, res)),
);

export default router;
