import { Router } from "express";
import { registrationController } from "../controllers/registration.controller";
import { validate } from "../middlewares/validate.middleware";
import {
  eventIdParamSchema2,
  listMyRegistrationsQuerySchema,
} from "../schemas/registration.schema";
import { authenticate, authorize } from "../middlewares/auth.middleware";
import { catchAsync } from "../utils/catchAsync";
import { eventRegistrationsQuerySchema } from "../schemas/registration.schema";

const router = Router();

// All registration routes require authentication
router.use(authenticate);

// GET /api/registrations/my — participant's own registrations
router.get(
  "/my",
  validate(listMyRegistrationsQuerySchema),
  catchAsync((req, res) => registrationController.listMine(req, res)),
);

// POST /api/registrations/events/:eventId — register for an event
router.post(
  "/events/:eventId",
  validate(eventIdParamSchema2),
  catchAsync((req, res) => registrationController.register(req, res)),
);

// DELETE /api/registrations/events/:eventId — cancel registration
router.delete(
  "/events/:eventId",
  validate(eventIdParamSchema2),
  catchAsync((req, res) => registrationController.cancel(req, res)),
);

// GET /api/registrations/events/:eventId — organizer/admin: view participants
router.get(
  "/events/:eventId",
  authorize("organizer", "admin"),
  validate({
    ...eventIdParamSchema2,
    ...listMyRegistrationsQuerySchema,
  } as any),
  catchAsync((req, res) => registrationController.listForEvent(req, res)),
);

router.get(
  "/events/:eventId",
  authorize("organizer", "admin"),
  validate(eventRegistrationsQuerySchema),
  catchAsync((req, res) => registrationController.listForEvent(req, res)),
);

export default router;
