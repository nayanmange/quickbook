import { Router } from "express";
import { eventController } from "../controllers/event.controller";
import { validate } from "../middlewares/validate.middleware";
import {
  createEventSchema,
  updateEventSchema,
  eventIdParamSchema,
  listEventsQuerySchema,
} from "../schemas/event.schema";
import { authenticate, authorize } from "../middlewares/auth.middleware";
import { catchAsync } from "../utils/catchAsync";

const router = Router();

// Public: browse events (with pagination/filtering)
router.get(
  "/",
  validate(listEventsQuerySchema),
  catchAsync((req, res) => eventController.list(req, res)),
);

// Authenticated: organizer's own events (must come before /:id to avoid route collision)
router.get(
  "/my",
  authenticate,
  authorize("organizer", "admin"),
  validate(listEventsQuerySchema),
  catchAsync((req, res) => eventController.listMine(req, res)),
);

// Public: view a single event
router.get(
  "/:id",
  validate(eventIdParamSchema),
  catchAsync((req, res) => eventController.getById(req, res)),
);

// Organizer/Admin only: create event
router.post(
  "/",
  authenticate,
  authorize("organizer", "admin"),
  validate(createEventSchema),
  catchAsync((req, res) => eventController.create(req, res)),
);

// Organizer (owner) /Admin only: update event
router.put(
  "/:id",
  authenticate,
  authorize("organizer", "admin"),
  validate(updateEventSchema),
  catchAsync((req, res) => eventController.update(req, res)),
);

// Organizer (owner) /Admin only: delete event
router.delete(
  "/:id",
  authenticate,
  authorize("organizer", "admin"),
  validate(eventIdParamSchema),
  catchAsync((req, res) => eventController.remove(req, res)),
);

export default router;
