import { Router } from "express";
import authRoutes from "./auth.routes";
import eventRoutes from "./event.routes";
import registrationRoutes from "./registration.routes";

const router = Router();

router.use("/auth", authRoutes);
router.use("/events", eventRoutes);
router.use("/registrations", registrationRoutes);

export default router;
