import { userRepository } from "../repositories/user.repository";
import { refreshTokenRepository } from "../repositories/refreshToken.repository";
import { AppError } from "../utils/AppError";
import {
  hashPassword,
  comparePassword,
  generateOpaqueToken,
  sha256,
} from "../utils/hash.util";
import { signAccessToken } from "../utils/jwt.util";
import { env } from "../config/env";
import { CreateUserInput, UserCredentials } from "../model/user.model";
import { AuthResponse } from "../model/auth.model";

export class AuthService {
  /**
   * Registers a new user and issues an initial token pair.
   */
  async register(
    input: CreateUserInput,
  ): Promise<AuthResponse & { refreshToken: string }> {
    const existing = await userRepository.findByEmail(input.email);
    if (existing) {
      throw AppError.conflict("An account with this email already exists");
    }

    const password_hash = await hashPassword(input.password);
    const user = await userRepository.create({ ...input, password_hash });

    const accessToken = signAccessToken({
      sub: user.id,
      email: user.email,
      role: user.role,
    });
    const refreshToken = await this.issueRefreshToken(user.id);

    return { user, accessToken, refreshToken };
  }

  /**
   * Validates credentials and issues a new token pair.
   */
  async login(
    credentials: UserCredentials,
  ): Promise<AuthResponse & { refreshToken: string }> {
    const user = await userRepository.findByEmail(credentials.email);
    if (!user) {
      throw AppError.unauthorized("Invalid email or password");
    }

    const isValid = await comparePassword(
      credentials.password,
      user.password_hash,
    );
    if (!isValid) {
      throw AppError.unauthorized("Invalid email or password");
    }

    const accessToken = signAccessToken({
      sub: user.id,
      email: user.email,
      role: user.role,
    });
    const refreshToken = await this.issueRefreshToken(user.id);

    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { password_hash: _, ...safeUser } = user;

    return { user: safeUser, accessToken, refreshToken };
  }

  /**
   * Validates an incoming refresh token, rotates it (revoke old, issue new),
   * and returns a fresh access + refresh token pair.
   */
  async refresh(
    incomingToken: string,
  ): Promise<AuthResponse & { refreshToken: string }> {
    if (!incomingToken) {
      throw AppError.unauthorized("Refresh token missing");
    }

    const tokenHash = sha256(incomingToken);
    const record = await refreshTokenRepository.findByHash(tokenHash);

    if (!record) {
      throw AppError.unauthorized("Invalid refresh token");
    }

    if (record.revoked) {
      // Possible token reuse/theft — revoke all tokens for this user as a precaution
      await refreshTokenRepository.revokeAllForUser(record.user_id);
      throw AppError.unauthorized(
        "Refresh token has been revoked. Please log in again.",
      );
    }

    if (new Date(record.expires_at).getTime() < Date.now()) {
      throw AppError.unauthorized(
        "Refresh token expired. Please log in again.",
      );
    }

    const user = await userRepository.findById(record.user_id);
    if (!user) {
      throw AppError.unauthorized("User no longer exists");
    }

    // Rotation: revoke the used token, issue a brand new one
    await refreshTokenRepository.revokeById(record.id);

    const accessToken = signAccessToken({
      sub: user.id,
      email: user.email,
      role: user.role,
    });
    const refreshToken = await this.issueRefreshToken(user.id);

    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { password_hash: _, ...safeUser } = user;

    return { user: safeUser, accessToken, refreshToken };
  }

  /**
   * Revokes the given refresh token (logout).
   */
  async logout(incomingToken: string | undefined): Promise<void> {
    if (!incomingToken) return; // idempotent — no token, nothing to revoke

    const tokenHash = sha256(incomingToken);
    await refreshTokenRepository.revokeByHash(tokenHash);
  }

  /**
   * Generates a new opaque refresh token, hashes it for storage,
   * and persists it with its expiry.
   */
  private async issueRefreshToken(userId: number): Promise<string> {
    const token = generateOpaqueToken();
    const tokenHash = sha256(token);
    const expiresAt = new Date(Date.now() + env.JWT_REFRESH_EXPIRES_IN_MS);

    await refreshTokenRepository.create(userId, tokenHash, expiresAt);

    return token;
  }
}

export const authService = new AuthService();
