// ============================================
// src/services/event.service.ts
// ============================================

import { eventRepository } from "../repositories/event.repository";
import { AppError } from "../utils/AppError";
import {
  CreateEventInput,
  UpdateEventInput,
  Event,
  EventQueryFilters,
  PaginatedResult,
} from "../model/event.model";

export class EventService {
  async createEvent(
    organizerId: number,
    input: CreateEventInput,
  ): Promise<Event> {
    return eventRepository.create(organizerId, input);
  }

  async getEventById(id: number): Promise<Event> {
    const event = await eventRepository.findById(id);
    if (!event) {
      throw AppError.notFound("Event not found");
    }
    return event;
  }

  async listEvents(
    filters: EventQueryFilters,
  ): Promise<PaginatedResult<Event>> {
    return eventRepository.findAll(filters);
  }

  /**
   * Updates an event. Only the organizing user (or admin) may update.
   * Enforces that capacity cannot be reduced below the current registered_count.
   */
  async updateEvent(
    id: number,
    requestingUserId: number,
    requestingUserRole: string,
    input: UpdateEventInput,
  ): Promise<Event> {
    const event = await this.getEventById(id);

    this.assertOwnership(event, requestingUserId, requestingUserRole);

    if (
      input.capacity !== undefined &&
      input.capacity < event.registered_count
    ) {
      throw AppError.badRequest(
        `Capacity cannot be set below the current registered count (${event.registered_count})`,
      );
    }

    const updated = await eventRepository.update(id, input);
    if (!updated) {
      throw AppError.notFound("Event not found");
    }
    return updated;
  }

  async deleteEvent(
    id: number,
    requestingUserId: number,
    requestingUserRole: string,
  ): Promise<void> {
    const event = await this.getEventById(id);

    this.assertOwnership(event, requestingUserId, requestingUserRole);

    const deleted = await eventRepository.delete(id);
    if (!deleted) {
      throw AppError.notFound("Event not found");
    }
  }

  /**
   * Ensures the requesting user owns the event, unless they're an admin.
   */
  private assertOwnership(event: Event, userId: number, role: string): void {
    if (role === "admin") return;
    if (event.organizer_id !== userId) {
      throw AppError.forbidden(
        "You do not have permission to modify this event",
      );
    }
  }
}

export const eventService = new EventService();
