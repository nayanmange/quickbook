// ============================================
// src/services/registration.service.ts
// ============================================

import { withTransaction } from "../config/database";
import { eventRepository } from "../repositories/event.repository";
import { registrationRepository } from "../repositories/registration.repository";
import { AppError } from "../utils/AppError";
import {
  Registration,
  RegistrationStatus,
  RegistrationWithEvent,
} from "../model/registration.model";
import { PaginatedResult } from "../model/event.model";

export class RegistrationService {
  /**
   * Registers a user for an event.
   *
   * Critical section wrapped in a transaction with SELECT ... FOR UPDATE on the
   * event row. This serializes concurrent registration attempts for the same
   * event — the second transaction blocks until the first commits/rolls back,
   * preventing two users from claiming the last available slot simultaneously.
   */
  async registerForEvent(
    eventId: number,
    userId: number,
  ): Promise<Registration> {
    return withTransaction(async (conn) => {
      // 1. Lock the event row — blocks other concurrent registrations for this event
      const event = await eventRepository.findByIdForUpdate(eventId, conn);

      if (!event) {
        throw AppError.notFound("Event not found");
      }

      if (event.status !== "published") {
        throw AppError.badRequest(
          "Registrations are only open for published events",
        );
      }

      if (new Date(event.start_time).getTime() <= Date.now()) {
        throw AppError.badRequest(
          "Cannot register for an event that has already started",
        );
      }

      // 2. Check for an existing registration row (lock it too, to prevent race
      //    on the unique constraint when re-registering after cancellation)
      const existing = await registrationRepository.findByEventAndUserForUpdate(
        eventId,
        userId,
        conn,
      );

      if (existing && existing.status !== "cancelled") {
        throw AppError.conflict("You are already registered for this event");
      }

      // 3. Capacity check — safe because the event row is locked (FOR UPDATE)
      const isFull = event.registered_count >= event.capacity;
      const newStatus: RegistrationStatus = isFull ? "waitlisted" : "confirmed";

      let registrationId: number;

      if (existing) {
        // Re-activate a previously cancelled registration
        await registrationRepository.reactivate(existing.id, newStatus, conn);
        registrationId = existing.id;
      } else {
        registrationId = await registrationRepository.create(
          eventId,
          userId,
          newStatus,
          conn,
        );
      }

      // 4. Only increment the counter for confirmed seats (not waitlisted)
      if (newStatus === "confirmed") {
        await eventRepository.incrementRegisteredCount(eventId, conn, 1);
      }

      // IMPORTANT: read back via the TRANSACTION connection (`conn`), not the
      // shared pool. The insert/update above is uncommitted at this point —
      // a query on a different pooled connection cannot see it under MySQL's
      // default REPEATABLE READ isolation and will return null, which
      // previously surfaced as "Failed to retrieve created registration".
      const registration = await registrationRepository.findByIdWithConn(
        registrationId,
        conn,
      );
      if (!registration) {
        throw new Error("Failed to retrieve created registration");
      }

      return registration;
    });
  }

  /**
   * Cancels a user's registration. If the cancelled registration was 'confirmed',
   * decrements the event's counter and promotes the earliest waitlisted user (if any).
   */
  async cancelRegistration(eventId: number, userId: number): Promise<void> {
    return withTransaction(async (conn) => {
      const event = await eventRepository.findByIdForUpdate(eventId, conn);
      if (!event) {
        throw AppError.notFound("Event not found");
      }

      const registration =
        await registrationRepository.findByEventAndUserForUpdate(
          eventId,
          userId,
          conn,
        );

      if (!registration || registration.status === "cancelled") {
        throw AppError.notFound("Active registration not found");
      }

      const wasConfirmed = registration.status === "confirmed";

      await registrationRepository.cancel(registration.id, conn);

      if (wasConfirmed) {
        await eventRepository.incrementRegisteredCount(eventId, conn, -1);
        await this.promoteFromWaitlist(eventId, conn);
      }
    });
  }

  /**
   * Promotes the earliest waitlisted registration to 'confirmed' and
   * increments the counter — keeps capacity fully utilized after a cancellation.
   * Must be called within the same transaction as the freeing cancellation.
   */
  private async promoteFromWaitlist(eventId: number, conn: any): Promise<void> {
    const [rows] = await conn.query(
      `SELECT id FROM registrations
       WHERE event_id = ? AND status = 'waitlisted'
       ORDER BY registered_at ASC
       LIMIT 1 FOR UPDATE`,
      [eventId],
    );

    const candidate = rows[0];
    if (!candidate) return;

    await conn.query(
      `UPDATE registrations SET status = 'confirmed' WHERE id = ?`,
      [candidate.id],
    );
    await eventRepository.incrementRegisteredCount(eventId, conn, 1);

    // NOTE: In production, enqueue a notification job here (e.g. "You've been
    // promoted from the waitlist") rather than sending synchronously inside the transaction.
  }

  async listMyRegistrations(
    userId: number,
    page: number,
    limit: number,
    status?: RegistrationStatus,
  ): Promise<PaginatedResult<RegistrationWithEvent>> {
    return registrationRepository.findByUser(userId, page, limit, status);
  }

  async listEventRegistrations(
    eventId: number,
    requestingUserId: number,
    requestingUserRole: string,
    page: number,
    limit: number,
    status?: RegistrationStatus,
  ) {
    const event = await eventRepository.findById(eventId);
    if (!event) {
      throw AppError.notFound("Event not found");
    }

    if (
      requestingUserRole !== "admin" &&
      event.organizer_id !== requestingUserId
    ) {
      throw AppError.forbidden(
        "You do not have permission to view these registrations",
      );
    }

    return registrationRepository.findByEvent(eventId, page, limit, status);
  }
}

export const registrationService = new RegistrationService();
