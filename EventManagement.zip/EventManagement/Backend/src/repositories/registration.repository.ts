// ============================================
// src/repositories/registration.repository.ts
// ============================================

import { pool } from "../config/database";
import { PoolConnection, ResultSetHeader, RowDataPacket } from "mysql2/promise";
import {
  Registration,
  RegistrationStatus,
  RegistrationWithEvent,
} from "../model/registration.model";
import { PaginatedResult } from "../model/event.model";

type RegistrationRow = Registration & RowDataPacket;
type RegistrationWithEventRow = RegistrationWithEvent & RowDataPacket;
type CountRow = { total: number } & RowDataPacket;

export class RegistrationRepository {
  /**
   * Finds an existing registration for (event, user), including soft-cancelled ones,
   * within an active transaction with a row lock — prevents duplicate-insert races.
   */
  async findByEventAndUserForUpdate(
    eventId: number,
    userId: number,
    conn: PoolConnection,
  ): Promise<Registration | null> {
    const [rows] = await conn.query<RegistrationRow[]>(
      `SELECT * FROM registrations WHERE event_id = ? AND user_id = ? LIMIT 1 FOR UPDATE`,
      [eventId, userId],
    );
    return rows[0] ?? null;
  }

  async create(
    eventId: number,
    userId: number,
    status: RegistrationStatus,
    conn: PoolConnection,
  ): Promise<number> {
    const [result] = await conn.query<ResultSetHeader>(
      `INSERT INTO registrations (event_id, user_id, status) VALUES (?, ?, ?)`,
      [eventId, userId, status],
    );
    return result.insertId;
  }

  /**
   * Reactivates a previously cancelled registration row instead of inserting a duplicate
   * (UNIQUE KEY uq_event_user prevents duplicate active rows).
   */
  async reactivate(
    id: number,
    status: RegistrationStatus,
    conn: PoolConnection,
  ): Promise<void> {
    await conn.query(
      `UPDATE registrations SET status = ?, cancelled_at = NULL, registered_at = UTC_TIMESTAMP() WHERE id = ?`,
      [status, id],
    );
  }

  async cancel(id: number, conn: PoolConnection): Promise<void> {
    await conn.query(
      `UPDATE registrations SET status = 'cancelled', cancelled_at = UTC_TIMESTAMP() WHERE id = ?`,
      [id],
    );
  }

  /**
   * Reads via the shared pool — safe ONLY for rows that are already
   * committed (e.g. outside of a transaction, such as controller-level
   * reads after a transaction has resolved).
   */
  async findById(id: number): Promise<Registration | null> {
    const [rows] = await pool.query<RegistrationRow[]>(
      `SELECT * FROM registrations WHERE id = ? LIMIT 1`,
      [id],
    );
    return rows[0] ?? null;
  }

  /**
   * Same as findById, but executes on the given transaction connection.
   *
   * REQUIRED when reading a row that was just INSERTed/UPDATEd within the
   * same open transaction: querying via the shared `pool` acquires a
   * DIFFERENT connection, which — under MySQL's default isolation level
   * (REPEATABLE READ) — cannot see this transaction's uncommitted writes.
   * Using `pool` here returns null even though the INSERT succeeded,
   * which surfaces as "Failed to retrieve created registration".
   */
  async findByIdWithConn(
    id: number,
    conn: PoolConnection,
  ): Promise<Registration | null> {
    const [rows] = await conn.query<RegistrationRow[]>(
      `SELECT * FROM registrations WHERE id = ? LIMIT 1`,
      [id],
    );
    return rows[0] ?? null;
  }

  async findActiveByEventAndUser(
    eventId: number,
    userId: number,
  ): Promise<Registration | null> {
    const [rows] = await pool.query<RegistrationRow[]>(
      `SELECT * FROM registrations WHERE event_id = ? AND user_id = ? AND status != 'cancelled' LIMIT 1`,
      [eventId, userId],
    );
    return rows[0] ?? null;
  }

  /**
   * Paginated list of a participant's registrations, joined with event details.
   */
  async findByUser(
    userId: number,
    page: number,
    limit: number,
    status?: RegistrationStatus,
  ): Promise<PaginatedResult<RegistrationWithEvent>> {
    const conditions = ["r.user_id = ?"];
    const values: any[] = [userId];

    if (status) {
      conditions.push("r.status = ?");
      values.push(status);
    }

    const whereClause = `WHERE ${conditions.join(" AND ")}`;

    const [countRows] = await pool.query<CountRow[]>(
      `SELECT COUNT(*) AS total FROM registrations r ${whereClause}`,
      values,
    );
    const total = countRows[0]?.total ?? 0;

    const offset = (page - 1) * limit;

    const [rows] = await pool.query<RegistrationWithEventRow[]>(
      `SELECT
         r.*,
         e.title AS event_title,
         e.start_time AS event_start_time,
         e.end_time AS event_end_time,
         e.status AS event_status
       FROM registrations r
       JOIN events e ON e.id = r.event_id
       ${whereClause}
       ORDER BY r.registered_at DESC
       LIMIT ? OFFSET ?`,
      [...values, limit, offset],
    );

    return {
      data: rows,
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }

  /**
   * Paginated list of participants registered for an event (organizer view).
   */
  async findByEvent(
    eventId: number,
    page: number,
    limit: number,
    status?: RegistrationStatus,
  ): Promise<
    PaginatedResult<Registration & { user_name: string; user_email: string }>
  > {
    const conditions = ["r.event_id = ?"];
    const values: any[] = [eventId];

    if (status) {
      conditions.push("r.status = ?");
      values.push(status);
    }

    const whereClause = `WHERE ${conditions.join(" AND ")}`;

    const [countRows] = await pool.query<CountRow[]>(
      `SELECT COUNT(*) AS total FROM registrations r ${whereClause}`,
      values,
    );
    const total = countRows[0]?.total ?? 0;

    const offset = (page - 1) * limit;

    const [rows] = await pool.query<RowDataPacket[]>(
      `SELECT r.*, u.name AS user_name, u.email AS user_email
       FROM registrations r
       JOIN users u ON u.id = r.user_id
       ${whereClause}
       ORDER BY r.registered_at ASC
       LIMIT ? OFFSET ?`,
      [...values, limit, offset],
    );

    return {
      data: rows as any,
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }
}

export const registrationRepository = new RegistrationRepository();
