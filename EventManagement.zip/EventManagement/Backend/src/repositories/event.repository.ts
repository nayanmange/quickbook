import { pool } from "../config/database";
import { ResultSetHeader, RowDataPacket } from "mysql2";
import { PoolConnection } from "mysql2/promise";
import {
  Event,
  CreateEventInput,
  UpdateEventInput,
  EventQueryFilters,
  PaginatedResult,
} from "../model/event.model";

type EventRow = Event & RowDataPacket;
type CountRow = { total: number } & RowDataPacket;

export class EventRepository {
  async create(organizerId: number, input: CreateEventInput): Promise<Event> {
    const [result] = await pool.query<ResultSetHeader>(
      `INSERT INTO events
        (organizer_id, title, description, type, location, is_online, capacity, start_time, end_time, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        organizerId,
        input.title,
        input.description ?? null,
        input.type,
        input.location ?? null,
        input.is_online ?? false,
        input.capacity,
        // Stored via mysql2 with timezone:'Z' — pass UTC ISO strings as Date objects
        new Date(input.start_time),
        new Date(input.end_time),
        input.status ?? "draft",
      ],
    );

    const created = await this.findById(result.insertId);
    if (!created) throw new Error("Failed to retrieve newly created event");
    return created;
  }

  async findById(id: number): Promise<Event | null> {
    const [rows] = await pool.query<EventRow[]>(
      `SELECT * FROM events WHERE id = ? LIMIT 1`,
      [id],
    );
    return rows[0] ?? null;
  }

  /**
   * Locks the event row for update within an active transaction.
   * Used by the registration flow to safely check/update capacity.
   */
  async findByIdForUpdate(
    id: number,
    conn: PoolConnection,
  ): Promise<Event | null> {
    const [rows] = await conn.query<EventRow[]>(
      `SELECT * FROM events WHERE id = ? LIMIT 1 FOR UPDATE`,
      [id],
    );
    return rows[0] ?? null;
  }

  async update(id: number, input: UpdateEventInput): Promise<Event | null> {
    const fields: string[] = [];
    const values: any[] = [];

    const fieldMap: Record<string, any> = {
      title: input.title,
      description: input.description,
      type: input.type,
      location: input.location,
      is_online: input.is_online,
      capacity: input.capacity,
      start_time: input.start_time ? new Date(input.start_time) : undefined,
      end_time: input.end_time ? new Date(input.end_time) : undefined,
      status: input.status,
    };

    for (const [key, value] of Object.entries(fieldMap)) {
      if (value !== undefined) {
        fields.push(`${key} = ?`);
        values.push(value);
      }
    }

    if (fields.length === 0) {
      return this.findById(id);
    }

    values.push(id);
    await pool.query(
      `UPDATE events SET ${fields.join(", ")} WHERE id = ?`,
      values,
    );

    return this.findById(id);
  }

  async delete(id: number): Promise<boolean> {
    const [result] = await pool.query<ResultSetHeader>(
      `DELETE FROM events WHERE id = ?`,
      [id],
    );
    return result.affectedRows > 0;
  }

  /**
   * Paginated, filterable list of events.
   * Supports filtering by type, status, organizer, and date range.
   */
  async findAll(filters: EventQueryFilters): Promise<PaginatedResult<Event>> {
    const conditions: string[] = [];
    const values: any[] = [];

    if (filters.type) {
      conditions.push("type = ?");
      values.push(filters.type);
    }

    if (filters.status) {
      conditions.push("status = ?");
      values.push(filters.status);
    }

    if (filters.organizer_id) {
      conditions.push("organizer_id = ?");
      values.push(filters.organizer_id);
    }

    if (filters.from) {
      conditions.push("start_time >= ?");
      values.push(new Date(filters.from));
    }

    if (filters.to) {
      conditions.push("start_time <= ?");
      values.push(new Date(filters.to));
    }

    const whereClause =
      conditions.length > 0 ? `WHERE ${conditions.join(" AND ")}` : "";

    const [countRows] = await pool.query<CountRow[]>(
      `SELECT COUNT(*) AS total FROM events ${whereClause}`,
      values,
    );
    const total = countRows[0]?.total ?? 0;

    const offset = (filters.page - 1) * filters.limit;

    const [rows] = await pool.query<EventRow[]>(
      `SELECT * FROM events ${whereClause} ORDER BY start_time ASC LIMIT ? OFFSET ?`,
      [...values, filters.limit, offset],
    );

    return {
      data: rows,
      pagination: {
        page: filters.page,
        limit: filters.limit,
        total,
        totalPages: Math.ceil(total / filters.limit),
      },
    };
  }

  /**
   * Atomically increments registered_count. Used inside the registration
   * transaction AFTER the row has been locked via findByIdForUpdate.
   */
  async incrementRegisteredCount(
    id: number,
    conn: PoolConnection,
    delta: number = 1,
  ): Promise<void> {
    await conn.query(
      `UPDATE events SET registered_count = registered_count + ? WHERE id = ?`,
      [delta, id],
    );
  }
}

export const eventRepository = new EventRepository();
