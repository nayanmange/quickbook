import { pool } from "../config/database";
import { ResultSetHeader, RowDataPacket } from "mysql2";
import { RefreshTokenRecord } from "../model/auth.model";

type RefreshTokenRow = RefreshTokenRecord & RowDataPacket;

export class RefreshTokenRepository {
  async create(
    userId: number,
    tokenHash: string,
    expiresAt: Date,
  ): Promise<number> {
    const [result] = await pool.query<ResultSetHeader>(
      `INSERT INTO refresh_tokens (user_id, token_hash, expires_at) VALUES (?, ?, ?)`,
      [userId, tokenHash, expiresAt],
    );
    return result.insertId;
  }

  async findByHash(tokenHash: string): Promise<RefreshTokenRecord | null> {
    const [rows] = await pool.query<RefreshTokenRow[]>(
      `SELECT * FROM refresh_tokens WHERE token_hash = ? LIMIT 1`,
      [tokenHash],
    );
    return rows[0] ?? null;
  }

  async revokeById(id: number): Promise<void> {
    await pool.query(`UPDATE refresh_tokens SET revoked = 1 WHERE id = ?`, [
      id,
    ]);
  }

  async revokeByHash(tokenHash: string): Promise<void> {
    await pool.query(
      `UPDATE refresh_tokens SET revoked = 1 WHERE token_hash = ?`,
      [tokenHash],
    );
  }

  /** Revoke all active tokens for a user (e.g. on password change or "logout everywhere") */
  async revokeAllForUser(userId: number): Promise<void> {
    await pool.query(
      `UPDATE refresh_tokens SET revoked = 1 WHERE user_id = ? AND revoked = 0`,
      [userId],
    );
  }

  /** Periodic cleanup of expired/revoked tokens (call from a cron job) */
  async deleteExpired(): Promise<void> {
    await pool.query(
      `DELETE FROM refresh_tokens WHERE expires_at < UTC_TIMESTAMP() OR revoked = 1`,
    );
  }
}

export const refreshTokenRepository = new RefreshTokenRepository();
