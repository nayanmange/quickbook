import { pool } from "../config/database";
import { ResultSetHeader, RowDataPacket } from "mysql2";
import { User, CreateUserInput, SafeUser } from "../model/user.model";

type UserRow = User & RowDataPacket;

const SAFE_FIELDS = "id, name, email, role, created_at, updated_at";

export class UserRepository {
  async findByEmail(email: string): Promise<User | null> {
    const [rows] = await pool.query<UserRow[]>(
      "SELECT * FROM users WHERE email = ? LIMIT 1",
      [email],
    );
    return rows[0] ?? null;
  }

  async findById(id: number): Promise<User | null> {
    const [rows] = await pool.query<UserRow[]>(
      "SELECT * FROM users WHERE id = ? LIMIT 1",
      [id],
    );
    return rows[0] ?? null;
  }

  async findSafeById(id: number): Promise<SafeUser | null> {
    const [rows] = await pool.query<UserRow[]>(
      `SELECT ${SAFE_FIELDS} FROM users WHERE id = ? LIMIT 1`,
      [id],
    );
    return rows[0] ?? null;
  }

  async create(
    input: CreateUserInput & { password_hash: string },
  ): Promise<SafeUser> {
    const [result] = await pool.query<ResultSetHeader>(
      `INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)`,
      [
        input.name,
        input.email,
        input.password_hash,
        input.role || "participant",
      ],
    );

    const created = await this.findSafeById(result.insertId);
    if (!created) {
      throw new Error("Failed to retrieve newly created user");
    }
    return created;
  }
}

export const userRepository = new UserRepository();
