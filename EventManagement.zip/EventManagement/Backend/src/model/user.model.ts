export type UserRole = "organizer" | "participant" | "admin";

export interface User {
  id: number;
  name: string;
  email: string;
  password_hash: string;
  role: UserRole;
  created_at: Date;
  updated_at: Date;
}

// Safe user object returned to clients (never expose password_hash)
export type SafeUser = Omit<User, "password_hash">;

export interface CreateUserInput {
  name: string;
  email: string;
  password: string;
  role?: UserRole;
}

export interface UserCredentials {
  email: string;
  password: string;
}
