export type RegistrationStatus = "confirmed" | "cancelled" | "waitlisted";

export interface Registration {
  id: number;
  event_id: number;
  user_id: number;
  status: RegistrationStatus;
  registered_at: Date;
  cancelled_at: Date | null;
}

export interface RegistrationWithEvent extends Registration {
  event_title: string;
  event_start_time: Date;
  event_end_time: Date;
  event_status: string;
}
