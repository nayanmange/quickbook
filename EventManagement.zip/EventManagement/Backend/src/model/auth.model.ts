import { UserRole } from "./user.model";

export interface JwtAccessPayload {
  sub: number; // user id
  email: string;
  role: UserRole;
  type: "access";
}

export interface JwtRefreshPayload {
  sub: number;
  type: "refresh";
  jti: string; // unique token id, used for revocation lookup
}

export interface RefreshTokenRecord {
  id: number;
  user_id: number;
  token_hash: string;
  expires_at: Date;
  revoked: boolean;
  created_at: Date;
}

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
}

export interface AuthResponse {
  user: import("./user.model").SafeUser;
  accessToken: string;
}
