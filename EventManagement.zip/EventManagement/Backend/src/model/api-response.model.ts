export type RegistrationStatus = "confirmed" | "cancelled" | "waitlisted";

export interface ApiSuccessResponse<T> {
  status: "success";
  data: T;
  message?: string;
}

export interface ApiErrorResponse {
  status: "error";
  message: string;
  statusCode: number;
  errors?: Record<string, string[]>;
}
