export type EventType =
  | "conference"
  | "workshop"
  | "webinar"
  | "meetup"
  | "training"
  | "corporate";

export type EventStatus = "draft" | "published" | "cancelled" | "completed";

export interface Event {
  id: number;
  organizer_id: number;
  title: string;
  description: string | null;
  type: EventType;
  location: string | null;
  is_online: boolean;
  capacity: number;
  registered_count: number;
  start_time: Date; // UTC
  end_time: Date; // UTC
  status: EventStatus;
  created_at: Date;
  updated_at: Date;
}

export interface CreateEventInput {
  title: string;
  description?: string;
  type: EventType;
  location?: string;
  is_online?: boolean;
  capacity: number;
  start_time: string; // ISO 8601 string from client, converted to UTC Date
  end_time: string;
  status?: EventStatus;
}

export interface UpdateEventInput extends Partial<CreateEventInput> {}

export interface EventQueryFilters {
  page: number;
  limit: number;
  type?: EventType;
  status?: EventStatus;
  organizer_id?: number;
  from?: string;
  to?: string;
}

export interface PaginatedResult<T> {
  data: T[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}
