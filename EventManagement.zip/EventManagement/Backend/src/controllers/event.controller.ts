import { Request, Response } from "express";
import { eventService } from "../services/event.service";
import {
  CreateEventDto,
  UpdateEventDto,
  ListEventsQueryDto,
} from "../schemas/event.schema";
import { ApiSuccessResponse } from "../model/api-response.model";
import { Event, PaginatedResult } from "../model/event.model";

export class EventController {
  async create(req: Request, res: Response): Promise<void> {
    const dto = req.body as CreateEventDto;
    const organizerId = req.user!.sub;

    const event = await eventService.createEvent(organizerId, dto);

    const response: ApiSuccessResponse<Event> = {
      status: "success",
      data: event,
      message: "Event created successfully",
    };
    res.status(201).json(response);
  }

  async getById(req: Request, res: Response): Promise<void> {
    const id = Number(req.params.id);
    const event = await eventService.getEventById(id);

    const response: ApiSuccessResponse<Event> = {
      status: "success",
      data: event,
    };
    res.status(200).json(response);
  }

  async list(req: Request, res: Response): Promise<void> {
    const query = req.query as unknown as ListEventsQueryDto;

    const result = await eventService.listEvents({
      page: query.page,
      limit: query.limit,
      type: query.type,
      status: query.status,
      from: query.from,
      to: query.to,
    });

    const response: ApiSuccessResponse<PaginatedResult<Event>> = {
      status: "success",
      data: result,
    };
    res.status(200).json(response);
  }

  async update(req: Request, res: Response): Promise<void> {
    const id = Number(req.params.id);
    const dto = req.body as UpdateEventDto;
    const { sub: userId, role } = req.user!;

    const event = await eventService.updateEvent(id, userId, role, dto);

    const response: ApiSuccessResponse<Event> = {
      status: "success",
      data: event,
      message: "Event updated successfully",
    };
    res.status(200).json(response);
  }

  async remove(req: Request, res: Response): Promise<void> {
    const id = Number(req.params.id);
    const { sub: userId, role } = req.user!;

    await eventService.deleteEvent(id, userId, role);

    const response: ApiSuccessResponse<null> = {
      status: "success",
      data: null,
      message: "Event deleted successfully",
    };
    res.status(200).json(response);
  }

  /**
   * GET /events/my — events organized by the requesting user.
   */
  async listMine(req: Request, res: Response): Promise<void> {
    const query = req.query as unknown as ListEventsQueryDto;
    const organizerId = req.user!.sub;

    const result = await eventService.listEvents({
      page: query.page,
      limit: query.limit,
      type: query.type,
      status: query.status,
      from: query.from,
      to: query.to,
      organizer_id: organizerId,
    });

    const response: ApiSuccessResponse<PaginatedResult<Event>> = {
      status: "success",
      data: result,
    };
    res.status(200).json(response);
  }
}

export const eventController = new EventController();
