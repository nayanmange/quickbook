import { Request, Response } from "express";
import { registrationService } from "../services/registration.service";
import { ApiSuccessResponse } from "../model/api-response.model";
import {
  Registration,
  RegistrationWithEvent,
} from "../model/registration.model";
import { PaginatedResult } from "../model/event.model";
import { ListMyRegistrationsQueryDto } from "../schemas/registration.schema";

export class RegistrationController {
  /** POST /events/:eventId/register */
  async register(req: Request, res: Response): Promise<void> {
    const eventId = Number(req.params.eventId);
    const userId = req.user!.sub;

    const registration = await registrationService.registerForEvent(
      eventId,
      userId,
    );

    const response: ApiSuccessResponse<Registration> = {
      status: "success",
      data: registration,
      message:
        registration.status === "waitlisted"
          ? "Event is at capacity — you have been added to the waitlist"
          : "Successfully registered for the event",
    };
    res.status(201).json(response);
  }

  /** DELETE /events/:eventId/register */
  async cancel(req: Request, res: Response): Promise<void> {
    const eventId = Number(req.params.eventId);
    const userId = req.user!.sub;

    await registrationService.cancelRegistration(eventId, userId);

    const response: ApiSuccessResponse<null> = {
      status: "success",
      data: null,
      message: "Registration cancelled successfully",
    };
    res.status(200).json(response);
  }

  /** GET /registrations/my */
  async listMine(req: Request, res: Response): Promise<void> {
    const userId = req.user!.sub;
    const query = req.query as unknown as ListMyRegistrationsQueryDto;

    const result = await registrationService.listMyRegistrations(
      userId,
      query.page,
      query.limit,
      query.status,
    );

    const response: ApiSuccessResponse<PaginatedResult<RegistrationWithEvent>> =
      {
        status: "success",
        data: result,
      };
    res.status(200).json(response);
  }

  /** GET /events/:eventId/registrations (organizer view) */
  async listForEvent(req: Request, res: Response): Promise<void> {
    const eventId = Number(req.params.eventId);
    const { sub: userId, role } = req.user!;
    const query = req.query as unknown as ListMyRegistrationsQueryDto;

    const result = await registrationService.listEventRegistrations(
      eventId,
      userId,
      role,
      query.page,
      query.limit,
      query.status,
    );

    const response: ApiSuccessResponse<typeof result.data> = {
      status: "success",
      data: result as any,
    };
    res.status(200).json(response);
  }
}

export const registrationController = new RegistrationController();
