import { Request, Response } from "express";
import { authService } from "../services/auth.service";
import {
  setRefreshTokenCookie,
  clearRefreshTokenCookie,
  REFRESH_COOKIE_NAME,
} from "../utils/cookies.util";
import { RegisterDto, LoginDto } from "../schemas/auth.schema";
import { ApiSuccessResponse } from "../model/api-response.model";
import { AuthResponse } from "../model/auth.model";

export class AuthController {
  async register(req: Request, res: Response): Promise<void> {
    const dto = req.body as RegisterDto;

    const { refreshToken, ...result } = await authService.register(dto);

    setRefreshTokenCookie(res, refreshToken);

    const response: ApiSuccessResponse<AuthResponse> = {
      status: "success",
      data: result,
      message: "Registration successful",
    };
    res.status(201).json(response);
  }

  async login(req: Request, res: Response): Promise<void> {
    const dto = req.body as LoginDto;

    const { refreshToken, ...result } = await authService.login(dto);

    setRefreshTokenCookie(res, refreshToken);

    const response: ApiSuccessResponse<AuthResponse> = {
      status: "success",
      data: result,
      message: "Login successful",
    };
    res.status(200).json(response);
  }

  async refresh(req: Request, res: Response): Promise<void> {
    const incomingToken = req.cookies?.[REFRESH_COOKIE_NAME];

    const { refreshToken, ...result } =
      await authService.refresh(incomingToken);

    setRefreshTokenCookie(res, refreshToken);

    const response: ApiSuccessResponse<AuthResponse> = {
      status: "success",
      data: result,
      message: "Token refreshed successfully",
    };
    res.status(200).json(response);
  }

  async logout(req: Request, res: Response): Promise<void> {
    const incomingToken = req.cookies?.[REFRESH_COOKIE_NAME];

    await authService.logout(incomingToken);

    clearRefreshTokenCookie(res);

    const response: ApiSuccessResponse<null> = {
      status: "success",
      data: null,
      message: "Logged out successfully",
    };
    res.status(200).json(response);
  }
}

export const authController = new AuthController();
