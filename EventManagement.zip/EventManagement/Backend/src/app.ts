import express, { Application } from "express";
import "express-async-errors";
import helmet from "helmet";
import cors from "cors";
import cookieParser from "cookie-parser";
import compression from "compression";
import morgan from "morgan";

import {
  notFoundHandler,
  globalErrorHandler,
} from "./middlewares/errorHandler.middleware";
import { logger } from "./config/logger";
import routes from "./routes";

export function createApp(): Application {
  const app = express();

  app.set("trust proxy", 1); // needed for correct req.ip behind a load balancer (rate limiting)

  app.use(helmet());
  app.use(
    cors({
      origin: process.env.CORS_ORIGIN?.split(",") || "*",
      credentials: true, // required for cookies (refresh token)
    }),
  );
  app.use(express.json({ limit: "10kb" }));
  app.use(express.urlencoded({ extended: true }));
  app.use(cookieParser());
  app.use(compression());

  app.use(
    morgan("combined", {
      stream: {
        write: (message: string) =>
          logger.http?.(message.trim()) || logger.info(message.trim()),
      },
    }),
  );

  app.get("/health", (req, res) => {
    res.status(200).json({ status: "ok", timestamp: new Date().toISOString() });
  });

  app.use("/api", routes);

  app.use(notFoundHandler);
  app.use(globalErrorHandler);

  return app;
}
