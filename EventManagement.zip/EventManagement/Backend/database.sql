use event_management;
CREATE TABLE users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('organizer', 'participant', 'admin') NOT NULL DEFAULT 'participant',
  created_at DATETIME NOT NULL DEFAULT (UTC_TIMESTAMP()),
  updated_at DATETIME NOT NULL DEFAULT (UTC_TIMESTAMP()),

  INDEX idx_users_email (email)
) ENGINE=InnoDB;

CREATE TABLE refresh_tokens (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  token_hash VARCHAR(255) NOT NULL,
  expires_at DATETIME NOT NULL,
  revoked TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT(UTC_TIMESTAMP()),

  CONSTRAINT fk_refresh_tokens_user
    FOREIGN KEY (user_id) REFERENCES users(id)
    ON DELETE CASCADE,

  INDEX idx_refresh_tokens_user (user_id),
  INDEX idx_refresh_tokens_hash (token_hash)
) ENGINE=InnoDB;

CREATE TABLE events (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  organizer_id INT UNSIGNED NOT NULL,
  title VARCHAR(200) NOT NULL,
  description TEXT,
  type ENUM('conference', 'workshop', 'webinar', 'meetup', 'training', 'corporate') NOT NULL,
  location VARCHAR(255),
  is_online TINYINT(1) NOT NULL DEFAULT 0,
  capacity INT UNSIGNED NOT NULL,
  registered_count INT UNSIGNED NOT NULL DEFAULT 0,
  start_time DATETIME NOT NULL COMMENT 'Stored in UTC',
  end_time DATETIME NOT NULL COMMENT 'Stored in UTC',
  status ENUM('draft', 'published', 'cancelled', 'completed') NOT NULL DEFAULT 'draft',
  created_at DATETIME NOT NULL DEFAULT (UTC_TIMESTAMP()),
  updated_at DATETIME NOT NULL DEFAULT (UTC_TIMESTAMP()),

  CONSTRAINT fk_events_organizer
    FOREIGN KEY (organizer_id) REFERENCES users(id)
    ON DELETE CASCADE,

  INDEX idx_events_organizer (organizer_id),
  INDEX idx_events_type (type),
  INDEX idx_events_status (status),
  INDEX idx_events_start_time (start_time),
  INDEX idx_events_type_status_start (type, status, start_time)
) ENGINE=InnoDB;

CREATE TABLE registrations (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  event_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  status ENUM('confirmed', 'cancelled', 'waitlisted') NOT NULL DEFAULT 'confirmed',
  registered_at DATETIME NOT NULL DEFAULT (UTC_TIMESTAMP()),
  cancelled_at DATETIME NULL,

  CONSTRAINT fk_registrations_event
    FOREIGN KEY (event_id) REFERENCES events(id)
    ON DELETE CASCADE,

  CONSTRAINT fk_registrations_user
    FOREIGN KEY (user_id) REFERENCES users(id)
    ON DELETE CASCADE,

  UNIQUE KEY uq_event_user (event_id, user_id),
  INDEX idx_registrations_event (event_id),
  INDEX idx_registrations_user (user_id),
  INDEX idx_registrations_status (status)
) ENGINE=InnoDB;