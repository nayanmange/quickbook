const mongoose = require('mongoose');

const QuickbooksTokensSchema = new mongoose.Schema({
  accessToken: {
    type: String,
    required: true,
  },
  refreshToken: {
    type: String,
    required: true,
  },
  companyId: {
    type: String,
    required: true,
    unique: true, // Assuming one set of tokens per company
  },
  expiresIn: {
    type: Date,
    required: true,
  },
  // Optionally, store the creation/update timestamps
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
});

// Update updatedAt field on save
QuickbooksTokensSchema.pre('save', function (next) {
  this.updatedAt = Date.now();
  next();
});

module.exports = mongoose.model('QuickbooksTokens', QuickbooksTokensSchema);
