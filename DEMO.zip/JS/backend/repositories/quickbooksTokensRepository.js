const { QuickbooksTokens } = require('../models');
const {
  DatabaseError,
  DuplicateKeyError,
  DatabaseValidationError,
} = require('../utils/DatabaseError');

const findOne = async (query = {}) => {
  try {
    const tokens = await QuickbooksTokens.findOne(query);
    return tokens;
  } catch (error) {
    throw new DatabaseError(`Error fetching QuickBooks tokens: ${error.message}`);
  }
};

const save = async (tokens) => {
  try {
    const savedTokens = await tokens.save({ runValidators: true });
    return savedTokens;
  } catch (error) {
    if (error.code === 11000) {
      throw new DuplicateKeyError(
        `Duplicate QuickBooks token field: ${JSON.stringify(error.keyValue)}`
      );
    }
    if (error.name === 'ValidationError') {
      throw new DatabaseValidationError(`Validation error for QuickBooks tokens: ${error.message}`);
    }
    throw new DatabaseError(`Error saving QuickBooks tokens: ${error.message}`);
  }
};

const create = async (tokens) => {
  try {
    const newTokens = await QuickbooksTokens.create(tokens);
    return newTokens;
  } catch (error) {
    if (error.code === 11000) {
      throw new DuplicateKeyError(
        `Duplicate QuickBooks token field during creation: ${JSON.stringify(error.keyValue)}`
      );
    }
    if (error.name === 'ValidationError') {
      throw new DatabaseValidationError(
        `Validation error during QuickBooks token creation: ${error.message}`
      );
    }
    throw new DatabaseError(`Error creating QuickBooks tokens: ${error.message}`);
  }
};

const findOneAndUpdate = async (query, update) => {
  try {
    const tokens = await QuickbooksTokens.findOneAndUpdate(query, update, {
      new: true,
      upsert: true,
      runValidators: true,
    });
    return tokens;
  } catch (error) {
    if (error.code === 11000) {
      throw new DuplicateKeyError(
        `Duplicate QuickBooks token field during update: ${JSON.stringify(error.keyValue)}`
      );
    }
    if (error.name === 'ValidationError') {
      throw new DatabaseValidationError(
        `Validation error during QuickBooks token update: ${error.message}`
      );
    }
    throw new DatabaseError(`Error updating QuickBooks tokens: ${error.message}`);
  }
};

module.exports = {
  findOne,
  save,
  create,
  findOneAndUpdate,
};
