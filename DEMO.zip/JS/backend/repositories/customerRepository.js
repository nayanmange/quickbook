const { Customer } = require('../models');
const {
  DatabaseError,
  DocumentNotFoundError,
  DuplicateKeyError,
  DatabaseValidationError,
} = require('../utils/DatabaseError');

const find = async (query) => {
  try {
    const customers = await Customer.find(query);
    return customers;
  } catch (error) {
    throw new DatabaseError(`Error fetching customers: ${error.message}`);
  }
};

const upsert = async (query, update) => {
  try {
    const customer = await Customer.findOneAndUpdate(query, update, {
      upsert: true,
      new: true,
      runValidators: true,
    });
    return customer;
  } catch (error) {
    if (error.code === 11000) {
      throw new DuplicateKeyError(`Duplicate customer field: ${JSON.stringify(error.keyValue)}`);
    }
    if (error.name === 'ValidationError') {
      throw new DatabaseValidationError(`Validation error: ${error.message}`);
    }
    throw new DatabaseError(`Error upserting customer: ${error.message}`);
  }
};

const findLatest = async () => {
  try {
    const customer = await Customer.findOne().sort({ lastUpdated: -1 });
    if (!customer) {
      throw new DocumentNotFoundError('No customers found.');
    }
    return customer;
  } catch (error) {
    if (error instanceof DatabaseError) {
      throw error; // Re-throw custom errors
    }
    throw new DatabaseError(`Error finding latest customer: ${error.message}`);
  }
};

module.exports = {
  find,
  upsert,
  findLatest,
};
