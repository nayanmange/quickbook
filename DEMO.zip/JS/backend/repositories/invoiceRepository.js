const { Invoice } = require('../models');
const {
  DatabaseError,
  DocumentNotFoundError,
  DuplicateKeyError,
  DatabaseValidationError,
} = require('../utils/DatabaseError');

const find = async (query) => {
  try {
    const invoices = await Invoice.find(query);
    return invoices;
  } catch (error) {
    throw new DatabaseError(`Error fetching invoices: ${error.message}`);
  }
};

const upsert = async (query, update) => {
  try {
    const invoice = await Invoice.findOneAndUpdate(query, update, {
      upsert: true,
      new: true,
      runValidators: true,
    });
    return invoice;
  } catch (error) {
    if (error.code === 11000) {
      throw new DuplicateKeyError(`Duplicate invoice field: ${JSON.stringify(error.keyValue)}`);
    }
    if (error.name === 'ValidationError') {
      throw new DatabaseValidationError(`Validation error: ${error.message}`);
    }
    throw new DatabaseError(`Error upserting invoice: ${error.message}`);
  }
};

const findLatest = async () => {
  try {
    const invoice = await Invoice.findOne().sort({ lastUpdated: -1 });
    if (!invoice) {
      throw new DocumentNotFoundError('No invoices found.');
    }
    return invoice;
  } catch (error) {
    if (error instanceof DatabaseError) {
      throw error; // Re-throw custom errors
    }
    throw new DatabaseError(`Error finding latest invoice: ${error.message}`);
  }
};

module.exports = {
  find,
  upsert,
  findLatest,
};
