const { validationResult } = require('express-validator');
const { BadRequestError } = require('../utils/AppError');

const validateRequest = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const errorMessages = errors.array().map((error) => error.msg);
    return next(new BadRequestError('Validation failed', errorMessages));
  }
  next();
};

module.exports = validateRequest;
