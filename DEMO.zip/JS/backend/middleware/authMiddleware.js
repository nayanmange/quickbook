const { UnauthorizedError } = require('../utils/AppError');
const logger = require('../utils/logger');

const protect = (req, res, next) => {
  if (!req.session || !req.session.oauthState) {
    logger.warn('Unauthorized access attempt: No active session or oauthState.');
    return next(new UnauthorizedError('You are not logged in! Please log in to get access.'));
  }

  logger.info('User authenticated via session.');
  next();
};

module.exports = { protect };
