const { AppError } = require('./AppError');

class DatabaseError extends AppError {
  constructor(message = 'Database operation failed', statusCode = 500) {
    super(message, statusCode);
    this.name = 'DatabaseError';
  }
}

class DocumentNotFoundError extends DatabaseError {
  constructor(message = 'Document not found', statusCode = 404) {
    super(message, statusCode);
    this.name = 'DocumentNotFoundError';
  }
}

class DuplicateKeyError extends DatabaseError {
  constructor(message = 'Duplicate key error', statusCode = 409) {
    super(message, statusCode);
    this.name = 'DuplicateKeyError';
  }
}

class DatabaseValidationError extends DatabaseError {
  constructor(message = 'Database validation failed', statusCode = 400) {
    super(message, statusCode);
    this.name = 'DatabaseValidationError';
  }
}

module.exports = {
  DatabaseError,
  DocumentNotFoundError,
  DuplicateKeyError,
  DatabaseValidationError,
};
