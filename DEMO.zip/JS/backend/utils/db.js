const mongoose = require('mongoose');
const logger = require('./logger');
const { MONGO_MESSAGES } = require('../constants');

const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    logger.info(MONGO_MESSAGES.CONNECTED);
  } catch (err) {
    logger.error(err.message);
    // Exit process with failure
    process.exit(1);
  }
};

module.exports = connectDB;
