const syncInvoiceService = require('../services/syncInvoiceService');
const Invoice = require('../models/Invoice'); // Direct Mongoose model import
const logger = require('../utils/logger');
const { HTTP_STATUS } = require('../constants'); // Import constants
const { AppError } = require('../utils/AppError');

const getInvoices = async (req, res, next) => {
  try {
    const invoices = await Invoice.find({});
    res.status(HTTP_STATUS.OK).json(invoices);
  } catch (error) {
    logger.error('Error fetching invoices from DB:', error.message);
    next(new AppError('Error fetching invoices from DB', HTTP_STATUS.INTERNAL_SERVER_ERROR));
  }
};

const fullSync = async (req, res, next) => {
  const { companyId } = req.body; // Assuming companyId is sent in the request body
  try {
    const syncedCount = await syncInvoiceService.fetchAllInvoices(companyId);
    const invoices = await Invoice.find({}); // Fetch updated list
    logger.info(
      `Full invoice sync completed for companyId ${companyId}. Synced ${syncedCount} invoices.`
    );
    res.status(HTTP_STATUS.OK).json(invoices);
  } catch (error) {
    logger.error(`Error during full invoice sync for companyId ${companyId}:`, error.message);
    next(
      new AppError(
        `Error during full invoice sync for companyId ${companyId}`,
        HTTP_STATUS.INTERNAL_SERVER_ERROR
      )
    );
  }
};

const deltaSync = async (req, res, next) => {
  const { companyId } = req.body; // Assuming companyId is sent in the request body
  try {
    const syncedCount = await syncInvoiceService.deltaSyncInvoices(companyId);
    logger.info(
      `Delta invoice sync completed for companyId ${companyId}. Synced ${syncedCount} invoices.`
    );
    res.status(HTTP_STATUS.OK).json({
      message: `Invoice delta sync completed successfully. Synced ${syncedCount} invoices.`,
    });
  } catch (error) {
    logger.error(`Error during delta invoice sync for companyId ${companyId}:`, error.message);
    next(
      new AppError(
        `Error during delta invoice sync for companyId ${companyId}`,
        HTTP_STATUS.INTERNAL_SERVER_ERROR
      )
    );
  }
};

module.exports = {
  getInvoices,
  fullSync,
  deltaSync,
};
