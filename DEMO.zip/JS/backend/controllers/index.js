module.exports = {
  authController: require('./authController'),
  customerController: require('./customerController'),
  invoiceController: require('./invoiceController'),
};
