const syncCustomerService = require('../services/syncCustomerService');
const Customer = require('../models/Customer'); // Direct Mongoose model import
const logger = require('../utils/logger');
const { HTTP_STATUS } = require('../constants'); // Import constants
const { AppError } = require('../utils/AppError');

const getCustomers = async (req, res, next) => {
  try {
    const customers = await Customer.find({});
    res.status(HTTP_STATUS.OK).json(customers); // Assuming 200 OK for success
  } catch (error) {
    logger.error('Error fetching customers from DB:', error.message);
    next(new AppError('Error fetching customers from DB', HTTP_STATUS.INTERNAL_SERVER_ERROR));
  }
};

const syncFull = async (req, res, next) => {
  const { companyId } = req.body; // Assuming companyId is sent in the request body
  try {
    const syncedCount = await syncCustomerService.fetchAllCustomers(companyId);
    const customers = await Customer.find({}); // Fetch updated list
    logger.info(
      `Full customer sync completed for companyId ${companyId}. Synced ${syncedCount} customers.`
    );
    res.status(HTTP_STATUS.OK).json(customers);
  } catch (error) {
    logger.error(`Error during full customer sync for companyId ${companyId}:`, error.message);
    next(
      new AppError(
        `Error during full customer sync for companyId ${companyId}`,
        HTTP_STATUS.INTERNAL_SERVER_ERROR
      )
    );
  }
};

const syncDelta = async (req, res, next) => {
  const { companyId } = req.body; // Assuming companyId is sent in the request body
  try {
    const syncedCount = await syncCustomerService.deltaSyncCustomers(companyId);
    logger.info(
      `Delta customer sync completed for companyId ${companyId}. Synced ${syncedCount} customers.`
    );
    res.status(HTTP_STATUS.OK).json({
      message: `Customer delta sync completed successfully. Synced ${syncedCount} customers.`,
    });
  } catch (error) {
    logger.error(`Error during delta customer sync for companyId ${companyId}:`, error.message);
    next(
      new AppError(
        `Error during delta customer sync for companyId ${companyId}`,
        HTTP_STATUS.INTERNAL_SERVER_ERROR
      )
    );
  }
};

module.exports = {
  getCustomers,
  syncFull,
  syncDelta,
};
