const quickbooksService = require('../services/quickbooksService');
const logger = require('../utils/logger');
const { AppError } = require('../utils/AppError');

const connect = (req, res) => {
  // Generate a random state to prevent CSRF attacks
  req.session.oauthState =
    Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
  const authUrl = quickbooksService.getAuthorizationUrl(req.session.oauthState); // Pass state to service
  res.redirect(authUrl);
};

const callback = async (req, res, next) => {
  const { code, realmId } = req.query;
  try {
    await quickbooksService.exchangeCodeForTokens(code, realmId);

    logger.info(`Quickbooks tokens saved for companyId: ${realmId}`);

    // Redirect to frontend home page with companyId
    res.redirect(`http://localhost:3000/home?companyId=${realmId}`);
  } catch (err) {
    logger.error('Error in Quickbooks OAuth callback:', err.message);
    next(new AppError('Error in Quickbooks OAuth callback', 500));
  }
};

module.exports = {
  connect,
  callback,
};
