const axios = require('axios');
const { quickbooksTokensRepository } = require('../repositories');
const logger = require('../utils/logger');

/**
 * Ensures a valid access token is available.
 * If the existing token is expired, it uses the refresh token to get a new one.
 * @returns {Promise<object>} The valid token object.
 */
const getValidToken = async () => {
  const tokens = await quickbooksTokensRepository.findOne();
  if (!tokens) {
    throw new Error('No Quickbooks tokens found. Please connect to Quickbooks first.');
  }

  // Check if the token is expired (or close to expiring)
  if (new Date() < new Date(tokens.expiresIn)) {
    return tokens; // Token is still valid
  }

  // If token is expired, refresh it
  logger.info('Refreshing Quickbooks token...');
  const tokenUrl = process.env.QUICKBOOKS_TOKEN_URL;
  const auth = Buffer.from(
    `${process.env.QUICKBOOKS_CLIENT_ID}:${process.env.QUICKBOOKS_CLIENT_SECRET}`
  ).toString('base64');

  try {
    const response = await axios.post(
      tokenUrl,
      new URLSearchParams({
        grant_type: 'refresh_token',
        refresh_token: tokens.refreshToken,
      }),
      {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          Authorization: `Basic ${auth}`,
        },
      }
    );

    const { access_token, refresh_token, expires_in } = response.data;

    // Update the tokens in the database
    tokens.accessToken = access_token;
    tokens.refreshToken = refresh_token;
    tokens.expiresIn = new Date(new Date().getTime() + expires_in * 1000);
    await quickbooksTokensRepository.save(tokens);

    logger.info('Successfully refreshed Quickbooks token.');
    return tokens;
  } catch (err) {
    logger.error('Error refreshing token', err.response ? err.response.data : 'Unknown error');
    throw new Error('Error refreshing Quickbooks token');
  }
};

const getApiUrl = (companyId) =>
  `https://sandbox-quickbooks.api.intuit.com/v3/company/${companyId}`;

module.exports = {
  getValidToken,
  getApiUrl,
};
