const QuickbooksService = require('./quickbooksService');
const Customer = require('../models/Customer');
const logger = require('../utils/logger');

const fetchAllCustomers = async (companyId) => {
  try {
    logger.info(`Starting full customer sync for companyId: ${companyId}`);
    const qbCustomers = await QuickbooksService.getCustomers(companyId);

    if (qbCustomers && qbCustomers.length > 0) {
      for (const qbCustomer of qbCustomers) {
        const customerData = {
          customerId: qbCustomer.Id,
          name: qbCustomer.DisplayName,
          email: qbCustomer.PrimaryEmailAddr ? qbCustomer.PrimaryEmailAddr.Address : undefined,
          lastUpdated: new Date(qbCustomer.MetaData.LastUpdatedTime),
        };

        await Customer.findOneAndUpdate({ customerId: customerData.customerId }, customerData, {
          upsert: true,
          new: true,
          setDefaultsOnInsert: true,
        });
      }
      logger.info(
        `Full customer sync completed for companyId: ${companyId}. Total customers: ${qbCustomers.length}`
      );
      return qbCustomers.length;
    } else {
      logger.info(`No customers found in Quickbooks for companyId: ${companyId}`);
      return 0;
    }
  } catch (error) {
    logger.error(`Error during full customer sync for companyId ${companyId}:`, error.message);
    throw error;
  }
};

const deltaSyncCustomers = async (companyId) => {
  try {
    logger.info(`Starting delta customer sync for companyId: ${companyId}`);
    // Find the last updated customer to get the 'since' date for delta sync
    const lastSyncedCustomer = await Customer.findOne({}).sort({ lastUpdated: -1 });
    const sinceDate = lastSyncedCustomer ? lastSyncedCustomer.lastUpdated : null;

    const qbCustomers = await QuickbooksService.getCustomers(companyId, sinceDate);

    if (qbCustomers && qbCustomers.length > 0) {
      for (const qbCustomer of qbCustomers) {
        const customerData = {
          customerId: qbCustomer.Id,
          name: qbCustomer.DisplayName,
          email: qbCustomer.PrimaryEmailAddr ? qbCustomer.PrimaryEmailAddr.Address : undefined,
          lastUpdated: new Date(qbCustomer.MetaData.LastUpdatedTime),
        };

        await Customer.findOneAndUpdate({ customerId: customerData.customerId }, customerData, {
          upsert: true,
          new: true,
          setDefaultsOnInsert: true,
        });
      }
      logger.info(
        `Delta customer sync completed for companyId: ${companyId}. Updated customers: ${qbCustomers.length}`
      );
      return qbCustomers.length;
    } else {
      logger.info(`No new or updated customers found in Quickbooks for companyId: ${companyId}`);
      return 0;
    }
  } catch (error) {
    logger.error(`Error during delta customer sync for companyId ${companyId}:`, error.message);
    throw error;
  }
};

module.exports = {
  fetchAllCustomers,
  deltaSyncCustomers,
};
