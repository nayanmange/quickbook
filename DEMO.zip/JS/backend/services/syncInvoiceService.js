const QuickbooksService = require('./quickbooksService');
const Invoice = require('../models/Invoice');
const logger = require('../utils/logger');

const fetchAllInvoices = async (companyId) => {
  try {
    logger.info(`Starting full invoice sync for companyId: ${companyId}`);
    const qbInvoices = await QuickbooksService.getInvoices(companyId);

    if (qbInvoices && qbInvoices.length > 0) {
      for (const qbInvoice of qbInvoices) {
        const invoiceData = {
          invoiceId: qbInvoice.Id,
          customerId: qbInvoice.CustomerRef.value,
          amount: qbInvoice.TotalAmt,
          status: qbInvoice.TxnStatus, // Or other relevant status field
          invoiceDate: new Date(qbInvoice.TxnDate),
          lastUpdated: new Date(qbInvoice.MetaData.LastUpdatedTime),
        };

        await Invoice.findOneAndUpdate({ invoiceId: invoiceData.invoiceId }, invoiceData, {
          upsert: true,
          new: true,
          setDefaultsOnInsert: true,
        });
      }
      logger.info(
        `Full invoice sync completed for companyId: ${companyId}. Total invoices: ${qbInvoices.length}`
      );
      return qbInvoices.length;
    } else {
      logger.info(`No invoices found in Quickbooks for companyId: ${companyId}`);
      return 0;
    }
  } catch (error) {
    logger.error(`Error during full invoice sync for companyId ${companyId}:`, error.message);
    throw error;
  }
};

const deltaSyncInvoices = async (companyId) => {
  try {
    logger.info(`Starting delta invoice sync for companyId: ${companyId}`);
    // Find the last updated invoice to get the 'since' date for delta sync
    const lastSyncedInvoice = await Invoice.findOne({}).sort({ lastUpdated: -1 });
    const sinceDate = lastSyncedInvoice ? lastSyncedInvoice.lastUpdated : null;

    const qbInvoices = await QuickbooksService.getInvoices(companyId, sinceDate);

    if (qbInvoices && qbInvoices.length > 0) {
      for (const qbInvoice of qbInvoices) {
        const invoiceData = {
          invoiceId: qbInvoice.Id,
          customerId: qbInvoice.CustomerRef.value,
          amount: qbInvoice.TotalAmt,
          status: qbInvoice.TxnStatus, // Or other relevant status field
          invoiceDate: new Date(qbInvoice.TxnDate),
          lastUpdated: new Date(qbInvoice.MetaData.LastUpdatedTime),
        };

        await Invoice.findOneAndUpdate({ invoiceId: invoiceData.invoiceId }, invoiceData, {
          upsert: true,
          new: true,
          setDefaultsOnInsert: true,
        });
      }
      logger.info(
        `Delta invoice sync completed for companyId: ${companyId}. Updated invoices: ${qbInvoices.length}`
      );
      return qbInvoices.length;
    } else {
      logger.info(`No new or updated invoices found in Quickbooks for companyId: ${companyId}`);
      return 0;
    }
  } catch (error) {
    logger.error(`Error during delta invoice sync for companyId ${companyId}:`, error.message);
    throw error;
  }
};

module.exports = {
  fetchAllInvoices,
  deltaSyncInvoices,
};
