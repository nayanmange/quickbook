const axios = require('axios');
const quickbooksTokensRepository = require('../repositories/quickbooksTokensRepository');
const logger = require('../utils/logger');
const { AppError } = require('../utils/AppError');
const { DatabaseError, DocumentNotFoundError } = require('../utils/DatabaseError');

// Quickbooks API Endpoints from .env
const QB_CLIENT_ID = process.env.QUICKBOOKS_CLIENT_ID;
const QB_CLIENT_SECRET = process.env.QUICKBOOKS_CLIENT_SECRET;
const QB_REDIRECT_URI = process.env.QUICKBOOKS_REDIRECT_URI;
const QB_SCOPES = process.env.QUICKBOOKS_SCOPES;
const QB_TOKEN_URL = process.env.QUICKBOOKS_TOKEN_URL;
const QB_AUTH_URL = process.env.QUICKBOOKS_AUTH_URL;
const QB_API_BASE_URL = process.env.QUICKBOOKS_API_BASE_URL;

if (!QB_CLIENT_ID || !QB_CLIENT_SECRET || !QB_REDIRECT_URI || !QB_SCOPES) {
  logger.error('Missing Quickbooks environment variables.');
  throw new AppError('Quickbooks API credentials are not set in environment variables.', 500);
}

const getAuthorizationUrl = (state) => {
  const params = new URLSearchParams({
    client_id: QB_CLIENT_ID,
    response_type: 'code',
    scope: QB_SCOPES,
    redirect_uri: QB_REDIRECT_URI,
    state: state,
  });
  const authUrl = `${QB_AUTH_URL}?${params.toString()}`;
  logger.info(`Generated Quickbooks Authorization URL: ${authUrl}`);
  return authUrl;
};

const exchangeCodeForTokens = async (authCode, companyId = null) => {
  try {
    const basic = Buffer.from(`${QB_CLIENT_ID}:${QB_CLIENT_SECRET}`).toString('base64');
    const params = new URLSearchParams({
      grant_type: 'authorization_code',
      code: authCode,
      redirect_uri: QB_REDIRECT_URI,
    });

    const { data } = await axios.post(QB_TOKEN_URL, params, {
      headers: {
        Accept: 'application/json',
        Authorization: `Basic ${basic}`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
    });

    const accessToken = data.access_token;
    const refreshToken = data.refresh_token;
    const expiresInSeconds = data.expires_in;

    if (!accessToken || !refreshToken || !expiresInSeconds) {
      logger.error('QuickBooks token endpoint returned incomplete data', data);
      throw new AppError('Incomplete token response from QuickBooks', 500);
    }

    const expiresAt = new Date(Date.now() + expiresInSeconds * 1000);
    logger.info('Successfully exchanged authorization code for tokens.');

    if (companyId) {
      await quickbooksTokensRepository.findOneAndUpdate(
        { companyId },
        { accessToken, refreshToken, expiresIn: expiresAt }
      );
    }

    return { accessToken, refreshToken, expiresIn: expiresAt };
  } catch (error) {
    logger.error(
      'Error exchanging code for tokens:',
      error.response ? error.response.data : error.message
    );
    throw new AppError(
      'Failed to exchange authorization code for tokens.',
      error.response ? error.response.status : 500
    );
  }
};

const refreshToken = async (companyId) => {
  try {
    let qbTokens = await quickbooksTokensRepository.findOne({ companyId });
    if (!qbTokens || !qbTokens.refreshToken) {
      throw new DocumentNotFoundError('No refresh token found for this company.');
    }

    const encodedCredentials = Buffer.from(`${QB_CLIENT_ID}:${QB_CLIENT_SECRET}`).toString(
      'base64'
    );
    const response = await axios.post(
      QB_TOKEN_URL,
      new URLSearchParams({
        grant_type: 'refresh_token',
        refresh_token: qbTokens.refreshToken,
      }),
      {
        headers: {
          Accept: 'application/json',
          Authorization: `Basic ${encodedCredentials}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
      }
    );

    const { access_token, refresh_token, expires_in } = response.data;
    const accessTokenExpiresAt = new Date(Date.now() + expires_in * 1000);

    qbTokens.accessToken = access_token;
    if (refresh_token) {
      // Only update refresh token if a new one is provided
      qbTokens.refreshToken = refresh_token;
    }
    qbTokens.expiresIn = accessTokenExpiresAt;
    await quickbooksTokensRepository.save(qbTokens);

    logger.info(`Tokens refreshed for companyId: ${companyId}`);
    return qbTokens;
  } catch (error) {
    logger.error(
      `Error refreshing token for companyId ${companyId}:`,
      error.response ? error.response.data : error.message
    );
    throw new AppError(
      'Failed to refresh Quickbooks access token.',
      error.response ? error.response.status : 500
    );
  }
};

const getValidTokens = async (companyId) => {
  let qbTokens;
  try {
    qbTokens = await quickbooksTokensRepository.findOne({ companyId });
  } catch (error) {
    // Catch DatabaseError from repository
    throw new DatabaseError(`Error retrieving tokens from database: ${error.message}`);
  }

  if (!qbTokens) {
    throw new DocumentNotFoundError('Quickbooks tokens not found for this company.');
  }

  // Check if access token is expired (give a buffer of 5 minutes)
  if (new Date() >= new Date(qbTokens.expiresIn.getTime() - 5 * 60 * 1000)) {
    logger.info(
      `Access token expired or near expiry for companyId ${companyId}. Attempting refresh.`
    );
    qbTokens = await refreshToken(companyId);
  }

  return qbTokens;
};

const makeQbApiCall = async (companyId, endpoint, method = 'get', data = null, headers = {}) => {
  let qbTokens;
  qbTokens = await getValidTokens(companyId);

  const url = `${QB_API_BASE_URL}/${companyId}/${endpoint}`;

  try {
    const response = await axios({
      method,
      url,
      headers: {
        Authorization: `Bearer ${qbTokens.accessToken}`,
        Accept: 'application/json',
        ...headers,
      },
      data,
    });
    return response.data;
  } catch (error) {
    logger.error(
      `Quickbooks API call failed for companyId ${companyId}, endpoint ${endpoint}:`,
      error.response ? error.response.data : error.message
    );
    throw new AppError(
      `Failed to make Quickbooks API call: ${error.message}`,
      error.response ? error.response.status : 500
    );
  }
};

const getCustomers = async (companyId, since = null) => {
  let headers = {};
  if (since) {
    headers['If-Modified-Since'] = new Date(since).toUTCString();
    logger.info(
      `Fetching customers from Quickbooks for company ${companyId} modified since ${since}`
    );
  } else {
    logger.info(`Fetching all customers from Quickbooks for company ${companyId}`);
  }

  try {
    let query = 'SELECT * FROM Customer MAXRESULTS 1000';
    if (since) {
      const lastUpdatedDate = new Date(since).toISOString();
      query = `SELECT * FROM Customer WHERE MetaData.LastUpdatedTime >= '${lastUpdatedDate}' MAXRESULTS 1000`;
    }

    const response = await makeQbApiCall(companyId, `query?query=${encodeURIComponent(query)}`);
    return response.QueryResponse.Customer || [];
  } catch (error) {
    if (error.response && error.response.status === 304) {
      logger.info(`No customers modified since last sync for company ${companyId}.`);
      return []; // No new data
    }
    throw new AppError(
      `Error fetching customers from QuickBooks: ${error.message}`,
      error.response ? error.response.status : 500
    );
  }
};

const getInvoices = async (companyId, since = null) => {
  let headers = {};
  if (since) {
    headers['If-Modified-Since'] = new Date(since).toUTCString();
    logger.info(
      `Fetching invoices from Quickbooks for company ${companyId} modified since ${since}`
    );
  } else {
    logger.info(`Fetching all invoices from Quickbooks for company ${companyId}`);
  }

  try {
    let query = 'SELECT * FROM Invoice MAXRESULTS 1000';
    if (since) {
      const lastUpdatedDate = new Date(since).toISOString();
      query = `SELECT * FROM Invoice WHERE MetaData.LastUpdatedTime >= '${lastUpdatedDate}' MAXRESULTS 1000`;
    }

    const response = await makeQbApiCall(companyId, `query?query=${encodeURIComponent(query)}`);
    return response.QueryResponse.Invoice || [];
  } catch (error) {
    if (error.response && error.response.status === 304) {
      logger.info(`No invoices modified since last sync for company ${companyId}.`);
      return []; // No new data
    }
    throw new AppError(
      `Error fetching invoices from QuickBooks: ${error.message}`,
      error.response ? error.response.status : 500
    );
  }
};

module.exports = {
  getAuthorizationUrl,
  exchangeCodeForTokens,
  refreshToken,
  getValidTokens,
  makeQbApiCall,
  getCustomers,
  getInvoices,
};
