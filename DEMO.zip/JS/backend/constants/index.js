const DEFAULT_PORT = parseInt(process.env.PORT) || 5000;
const CORS_ORIGIN_DEVELOPMENT = process.env.CORS_ORIGIN || 'http://localhost:3000';
const DEFAULT_SESSION_SECRET = process.env.SESSION_SECRET || 'default_secret';
const SESSION_COOKIE_MAX_AGE_ONE_DAY =
  parseInt(process.env.SESSION_COOKIE_MAX_AGE) || 1000 * 60 * 60 * 24; // 1 day

const API_VERSION = '/v1';

const API_ROUTES = {
  BASE: `/api${API_VERSION}`,
  AUTH: `/api${API_VERSION}/auth`,
  CUSTOMERS: `/api${API_VERSION}/customers`,
  INVOICES: `/api${API_VERSION}/invoices`,
};

const MONGO_MESSAGES = {
  CONNECTED: 'MongoDB connected',
};

const SERVER_MESSAGES = {
  ROOT_GET_SUCCESS: 'Quickbooks MERN App',
  SOMETHING_BROKE: 'Something broke!',
  SERVER_RUNNING_ON_PORT: (port) => `Server is running on port ${port}`,
};

const HTTP_STATUS = {
  OK: 200,
  BAD_REQUEST: 400,
  INTERNAL_SERVER_ERROR: 500,
};

module.exports = {
  DEFAULT_PORT,
  CORS_ORIGIN_DEVELOPMENT,
  DEFAULT_SESSION_SECRET,
  SESSION_COOKIE_MAX_AGE_ONE_DAY,
  API_VERSION, // Export API_VERSION
  API_ROUTES,
  MONGO_MESSAGES,
  SERVER_MESSAGES,
  HTTP_STATUS,
};
