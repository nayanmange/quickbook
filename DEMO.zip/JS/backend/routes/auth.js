const express = require('express');
const router = express.Router();
const { query } = require('express-validator');
const { authController } = require('../controllers');

router.get('/connect', authController.connect);

router.get(
  '/callback',
  [
    query('code').exists().withMessage('Code is required'),
    query('state')
      .exists()
      .withMessage('State is required')
      .custom((value, { req }) => {
        if (value !== req.session.oauthState) {
          throw new Error('Invalid OAuth state');
        }
        return true;
      }),
    query('realmId').exists().withMessage('Realm ID is required'),
  ],
  authController.callback
);

module.exports = router;
