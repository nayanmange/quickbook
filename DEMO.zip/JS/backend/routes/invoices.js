const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const { invoiceController } = require('../controllers');
const validateRequest = require('../middleware/validateRequest');
const { protect } = require('../middleware/authMiddleware');

router.use(protect);

router.get('/', invoiceController.getInvoices);

router.post(
  '/sync/full',
  [body('companyId').exists().withMessage('Company ID is required'), validateRequest],
  invoiceController.fullSync
);

router.post(
  '/sync/delta',
  [body('companyId').exists().withMessage('Company ID is required'), validateRequest],
  invoiceController.deltaSync
);

module.exports = router;
