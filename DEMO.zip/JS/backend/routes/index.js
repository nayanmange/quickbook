module.exports = {
  auth: require('./auth'),
  customers: require('./customers'),
  invoices: require('./invoices'),
};
