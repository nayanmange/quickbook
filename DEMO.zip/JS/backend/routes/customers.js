const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const { customerController } = require('../controllers');
const validateRequest = require('../middleware/validateRequest');
const { protect } = require('../middleware/authMiddleware');

router.use(protect);

router.get('/', customerController.getCustomers);

router.post(
  '/sync/full',
  [body('companyId').exists().withMessage('Company ID is required'), validateRequest],
  customerController.syncFull
);

router.post(
  '/sync/delta',
  [body('companyId').exists().withMessage('Company ID is required'), validateRequest],
  customerController.syncDelta
);

module.exports = router;
