require('dotenv').config();
const express = require('express');
const session = require('express-session');
const cors = require('cors');
const logger = require('./utils/logger');
const { NotFoundError } = require('./utils/AppError');
const globalErrorHandler = require('./utils/errorHandler');
const {
  DEFAULT_PORT,
  CORS_ORIGIN_DEVELOPMENT,
  DEFAULT_SESSION_SECRET,
  SESSION_COOKIE_MAX_AGE_ONE_DAY,
  API_ROUTES,
  SERVER_MESSAGES,
} = require('./constants');

const app = express();
const PORT = process.env.PORT || DEFAULT_PORT;

app.use(
  cors({
    origin: CORS_ORIGIN_DEVELOPMENT,
    credentials: true,
  })
);
app.use(express.json());

// Session middleware
app.use(
  session({
    secret: process.env.SESSION_SECRET || DEFAULT_SESSION_SECRET,
    resave: false,
    saveUninitialized: false, // Don't save uninitialized sessions
    cookie: {
      httpOnly: true, // Prevent client-side access to the cookie
      maxAge: SESSION_COOKIE_MAX_AGE_ONE_DAY, // 1 day
    },
  })
);

const connectDB = require('./utils/db');
connectDB();

const { auth, customers, invoices } = require('./routes');
app.use(API_ROUTES.AUTH, auth);
app.use(API_ROUTES.CUSTOMERS, customers);
app.use(API_ROUTES.INVOICES, invoices);

app.get('/', (req, res) => {
  res.send(SERVER_MESSAGES.ROOT_GET_SUCCESS);
});

// Handle unhandled routes
app.all('*', (req, res, next) => {
  next(new NotFoundError(`Can't find ${req.originalUrl} on this server!`));
});

// Global error handling middleware
app.use(globalErrorHandler);

app.listen(PORT, () => {
  logger.info(SERVER_MESSAGES.SERVER_RUNNING_ON_PORT(PORT));
});
