import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import logger from '../utils/logger';

const CompanyIdContext = createContext();

export const useCompanyId = () => {
  return useContext(CompanyIdContext);
};

export const CompanyIdProvider = ({ children }) => {
  const [companyId, setCompanyId] = useState(() => {
    // Initialize companyId from localStorage on first load
    return localStorage.getItem('companyId');
  });

  // Effect to update localStorage whenever companyId changes
  useEffect(() => {
    logger.debug(`CompanyIdContext: useEffect triggered. Current companyId: "${companyId}"`);
    if (companyId) {
      localStorage.setItem('companyId', companyId);
      logger.info(`Company ID set in context and localStorage: ${companyId}`);
    } else {
      localStorage.removeItem('companyId');
      logger.info('Company ID removed from context and localStorage.');
    }
  }, [companyId]);

  const updateCompanyId = useCallback(
    (newCompanyId) => {
      logger.debug(
        `CompanyIdContext: updateCompanyId called. New: "${newCompanyId}", Current: "${companyId}"`
      );
      if (newCompanyId !== companyId) {
        logger.info(`CompanyIdContext: Setting companyId to "${newCompanyId}"`);
        setCompanyId(newCompanyId);
      } else {
        logger.debug(
          `CompanyIdContext: newCompanyId "${newCompanyId}" is same as current, no update.`
        );
      }
    },
    [companyId]
  );

  return (
    <CompanyIdContext.Provider value={{ companyId, updateCompanyId }}>
      {children}
    </CompanyIdContext.Provider>
  );
};
