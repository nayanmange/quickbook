import React, { useEffect } from 'react'; // Import useEffect
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { Login, Home } from './components';
import ErrorBoundary from './components/ErrorBoundary'; // Import ErrorBoundary
import { ToastProvider } from './context/ToastContext'; // Import ToastProvider
import { CompanyIdProvider } from './context/CompanyIdContext'; // Import CompanyIdProvider
import { LoadingProvider, useLoading } from './context/LoadingContext'; // Import LoadingProvider and useLoading
import LoadingSpinner from './components/LoadingSpinner'; // Import LoadingSpinner
import { setupApiInterceptors } from './services/api'; // Import setupApiInterceptors
import './App.css';

function App() {
  return (
    <ToastProvider>
      <CompanyIdProvider>
        <LoadingProvider>
          {' '}
          {/* Wrap the entire application with LoadingProvider */}
          <AppContent /> {/* Render AppContent as a separate component to use useLoading */}
        </LoadingProvider>
      </CompanyIdProvider>
    </ToastProvider>
  );
}

function AppContent() {
  const { isLoading, startLoading, stopLoading } = useLoading(); // Get startLoading and stopLoading

  useEffect(() => {
    setupApiInterceptors(startLoading, stopLoading);
  }, [startLoading, stopLoading]); // Rerun if these functions change (unlikely)

  return (
    <ErrorBoundary>
      <Router>
        <div className="App">
          {isLoading && <LoadingSpinner />} {/* Conditionally render loading spinner */}
          <Routes>
            <Route path="/" element={<Login />} />
            <Route path="/home" element={<Home />} />
          </Routes>
        </div>
      </Router>
    </ErrorBoundary>
  );
}

export default App;
