import axios from 'axios';
import { API_ENDPOINTS } from '../constants';

const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

const api = axios.create({
  baseURL: API_BASE_URL,
  withCredentials: true, // Send cookies with requests
  headers: {
    'Content-Type': 'application/json',
  },
});

let setupDone = false;

export const setupApiInterceptors = (startLoading, stopLoading) => {
  if (setupDone) return;

  api.interceptors.request.use(
    (config) => {
      startLoading();
      // Example: if you had a token in localStorage
      // const token = localStorage.getItem('authToken');
      // if (token) {
      //     config.headers.Authorization = `Bearer ${token}`;
      // }
      return config;
    },
    (error) => {
      stopLoading();
      return Promise.reject(error);
    }
  );

  api.interceptors.response.use(
    (response) => {
      stopLoading();
      return response;
    },
    (error) => {
      stopLoading();
      // Example: Redirect to login on 401 Unauthorized
      if (error.response && error.response.status === 401) {
        console.error('Unauthorized, redirecting to login...', error);
        // window.location.href = '/'; // Or your login route
      }
      return Promise.reject(error);
    }
  );
  setupDone = true;
};

const apiService = {
  // Auth
  connectQuickbooks: () => api.get(API_ENDPOINTS.CONNECT_QUICKBOOKS),

  // Customers
  getCustomers: () => api.get(API_ENDPOINTS.CUSTOMERS),
  syncCustomersFull: (companyId) => api.post(API_ENDPOINTS.SYNC_CUSTOMERS_FULL, { companyId }),
  syncCustomersDelta: (companyId) => api.post(API_ENDPOINTS.SYNC_CUSTOMERS_DELTA, { companyId }),

  // Invoices
  getInvoices: () => api.get(API_ENDPOINTS.INVOICES),
  syncInvoicesFull: (companyId) => api.post(API_ENDPOINTS.SYNC_INVOICES_FULL, { companyId }),
  syncInvoicesDelta: (companyId) => api.post(API_ENDPOINTS.SYNC_INVOICES_DELTA, { companyId }),
};

export default apiService;
