import React from 'react';
import { API_ENDPOINTS } from '../constants';
import { useToast } from '../context/ToastContext'; // Import useToast

const Login = () => {
  const { showToast } = useToast(); // Use the useToast hook

  const handleLogin = () => {
    showToast('Redirecting to Quickbooks login...', 'info'); // Show a toast message
    window.location.href = `${process.env.REACT_APP_API_BASE_URL}${API_ENDPOINTS.CONNECT_QUICKBOOKS}`;
  };

  return (
    <div>
      <h2>Login Page</h2>
      <button onClick={handleLogin}>Login with Quickbooks</button>
    </div>
  );
};

export default Login;
