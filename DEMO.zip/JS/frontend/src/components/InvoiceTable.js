import React from 'react';

const InvoiceTable = ({ invoices }) => {
  return (
    <div>
      <h3>Invoices</h3>
      <table>
        <thead>
          <tr>
            <th scope="col">ID</th>
            <th scope="col">Customer ID</th>
            <th scope="col">Amount</th>
            <th scope="col">Status</th>
            <th scope="col">Date</th>
          </tr>
        </thead>
        <tbody>
          {invoices.map((invoice) => (
            <tr key={invoice.invoiceId}>
              <td>{invoice.invoiceId}</td>
              <td>{invoice.customerId}</td>
              <td>{invoice.amount}</td>
              <td>{invoice.status}</td>
              <td>{new Date(invoice.invoiceDate).toLocaleDateString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default InvoiceTable;
