import React, { useState, useEffect, useCallback } from 'react';
import apiService from '../services/api';
import logger from '../utils/logger';
import { useToast } from '../context/ToastContext';
import { useCompanyId } from '../context/CompanyIdContext'; // Import useCompanyId
import CustomerTable from './CustomerTable'; // Import CustomerTable
import InvoiceTable from './InvoiceTable'; // Import InvoiceTable
import SyncButtons from './SyncButtons'; // Import SyncButtons

const Home = () => {
  const [customers, setCustomers] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const { showToast } = useToast();
  const { companyId, updateCompanyId } = useCompanyId(); // Use the useCompanyId hook

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const companyIdFromUrl = urlParams.get('companyId');

    if (companyIdFromUrl) {
      updateCompanyId(companyIdFromUrl); // Update context and localStorage
      // Clean the URL to remove the companyId query parameter
      window.history.replaceState({}, document.title, window.location.pathname);
      showToast('Quickbooks connected successfully!', 'success');
    }
    // companyId is now managed by the context, which initializes from localStorage
  }, [showToast, updateCompanyId]);

  const fetchCustomers = useCallback(async () => {
    if (!companyId) {
      logger.warn('Cannot fetch customers: companyId is missing.');
      showToast('Company ID missing for customer fetch.', 'error');
      return;
    }
    try {
      const res = await apiService.getCustomers();
      setCustomers(res.data);
      showToast('Customers fetched successfully!', 'success');
    } catch (err) {
      logger.error('Error fetching customers:', err);
      showToast('Failed to fetch customers.', 'error');
    }
  }, [companyId, showToast]);

  const fetchInvoices = useCallback(async () => {
    if (!companyId) {
      logger.warn('Cannot fetch invoices: companyId is missing.');
      showToast('Company ID missing for invoice fetch.', 'error');
      return;
    }
    try {
      const res = await apiService.getInvoices();
      setInvoices(res.data);
      showToast('Invoices fetched successfully!', 'success');
    } catch (err) {
      logger.error('Error fetching invoices:', err);
      showToast('Failed to fetch invoices.', 'error');
    }
  }, [companyId, showToast]);

  useEffect(() => {
    console.count('Home useEffect fetch data'); // Debugging
    if (companyId) {
      fetchCustomers();
      fetchInvoices();
    }
  }, [companyId, fetchCustomers, fetchInvoices]); // Refetch when companyId becomes available from context

  const fullSyncInvoices = useCallback(async () => {
    if (!companyId) {
      logger.warn('Cannot perform full invoice sync: companyId is missing.');
      showToast('Company ID missing for full invoice sync.', 'error');
      return;
    }
    try {
      await apiService.syncInvoicesFull(companyId);
      fetchInvoices(); // Refresh invoices after sync
      showToast('Full invoice sync initiated successfully!', 'success');
      logger.info('Full invoice sync initiated successfully.');
    } catch (err) {
      logger.error('Error during full invoice sync:', err);
      showToast('Failed to initiate full invoice sync.', 'error');
    }
  }, [companyId, showToast, fetchInvoices]);

  const deltaSyncCustomers = useCallback(async () => {
    if (!companyId) {
      logger.warn('Cannot perform delta customer sync: companyId is missing.');
      showToast('Company ID missing for delta customer sync.', 'error');
      return;
    }
    try {
      await apiService.syncCustomersDelta(companyId);
      fetchCustomers(); // Refresh customers after sync
      showToast('Delta customer sync initiated successfully!', 'success');
      logger.info('Delta customer sync initiated successfully.');
    } catch (err) {
      logger.error('Error during delta customer sync:', err);
      showToast('Failed to initiate delta customer sync.', 'error');
    }
  }, [companyId, showToast, fetchCustomers]);

  const deltaSyncInvoices = useCallback(async () => {
    if (!companyId) {
      logger.warn('Cannot perform delta invoice sync: companyId is missing.');
      showToast('Company ID missing for delta invoice sync.', 'error');
      return;
    }
    try {
      await apiService.syncInvoicesDelta(companyId);
      fetchInvoices(); // Refresh invoices after sync
      showToast('Delta invoice sync initiated successfully!', 'success');
      logger.info('Delta invoice sync initiated successfully.');
    } catch (err) {
      logger.error('Error during delta invoice sync:', err);
      showToast('Failed to initiate delta invoice sync.', 'error');
    }
  }, [companyId, showToast, fetchInvoices]);

  return (
    <div>
      <h2>Home</h2>
      <SyncButtons
        fetchCustomers={fetchCustomers}
        fullSyncInvoices={fullSyncInvoices}
        deltaSyncCustomers={deltaSyncCustomers}
        deltaSyncInvoices={deltaSyncInvoices}
      />
      <CustomerTable customers={customers} />
      <InvoiceTable invoices={invoices} />
    </div>
  );
};

export default Home;
