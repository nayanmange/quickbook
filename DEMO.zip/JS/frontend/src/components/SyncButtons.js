import React from 'react';

const SyncButtons = ({
  fetchCustomers,
  fullSyncInvoices,
  deltaSyncCustomers,
  deltaSyncInvoices,
}) => {
  return (
    <div>
      <button onClick={fetchCustomers}>Fetch Quickbooks Contacts</button>
      <button onClick={fullSyncInvoices}>Full Sync Invoices</button>
      <button onClick={deltaSyncCustomers}>Delta Sync Customers</button>
      <button onClick={deltaSyncInvoices}>Delta Sync Invoices</button>
    </div>
  );
};

export default SyncButtons;
