export const API_VERSION = '/v1';

export const API_ENDPOINTS = {
  CONNECT_QUICKBOOKS: `/api${API_VERSION}/auth/connect`,
  CUSTOMERS: `/api${API_VERSION}/customers`,
  INVOICES: `/api${API_VERSION}/invoices`,
  SYNC_INVOICES_FULL: `/api${API_VERSION}/invoices/sync/full`,
  SYNC_CUSTOMERS_DELTA: `/api${API_VERSION}/customers/sync/delta`,
  SYNC_INVOICES_DELTA: `/api${API_VERSION}/invoices/sync/delta`,
};
