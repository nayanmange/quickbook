# Quickbooks MERN Practical

This project is a MERN application that demonstrates how to implement OAuth 2.0 authentication with Quickbooks using REST APIs. It stores authentication tokens and company details in MongoDB and implements full and delta synchronization of Customers and Invoices.

## Prerequisites

- Node.js
- MongoDB

## Getting Started

### Backend

1.  Navigate to the `backend` directory:
    ```sh
    cd backend
    ```
2.  Install dependencies:
    ```sh
    npm install
    ```
3.  Create a `.env` file in the `backend` directory and add the following environment variables:
    ```
    MONGO_URI=your_mongodb_connection_string
    QUICKBOOKS_CLIENT_ID=your_quickbooks_client_id
    QUICKBOOKS_CLIENT_SECRET=your_quickbooks_client_secret
    QUICKBOOKS_REDIRECT_URI=http://localhost:3000/callback
    QUICKBOOKS_SCOPES=com.intuit.quickbooks.accounting
    QUICKBOOKS_TOKEN_URL=https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer
    QUICKBOOKS_AUTH_URL=https://appcenter.intuit.com/connect/oauth2
    ```
4.  Start the backend server:
    ```sh
    npm start
    ```

### Frontend

1.  Navigate to the `frontend` directory:
    ```sh
    cd frontend
    ```
2.  Install dependencies:
    ```sh
    npm install
    ```
3.  Start the frontend development server:
    ```sh
    npm start
    ```

The application will be available at `http://localhost:3000`.

## How to Use

1.  Open the application in your browser.
2.  Click the "Login with Quickbooks" button to authenticate with your Quickbooks account.
3.  After successful authentication, you will be redirected to the home page.
4.  On the home page, you can:
    -   Fetch your Quickbooks contacts.
    -   Perform a full sync of your invoices.
    -   Perform a delta sync of your customers.
    -   Perform a delta sync of your invoices.
    
The synchronized data will be displayed in tables on the home page.
